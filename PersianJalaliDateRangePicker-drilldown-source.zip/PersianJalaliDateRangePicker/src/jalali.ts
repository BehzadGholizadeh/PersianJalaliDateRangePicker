/**
 * Jalali (Persian / Shamsi) <-> Gregorian conversion — INTERNAL FALLBACK ONLY.
 *
 * The authoritative calendar is the SSAS `Dates_Dim` table supplied through the
 * visual's data roles (see calendar.ts). This module is used only for days that
 * are not present in the received data (e.g. months outside the model's range,
 * or when the JalaliDate role is not bound).
 *
 * Algorithm: the "breaks" based arithmetic calendar by Kazimierz M. Borkowski,
 * as popularised by the MIT-licensed `jalaali-js` package. It agrees with the
 * official Iranian calendar for years 1178–1633 AP. Implemented here from the
 * published algorithm so the visual has zero runtime dependencies.
 *
 * Every day is represented as an integer Julian Day Number (JDN). Using an
 * integer day number instead of JavaScript `Date` arithmetic makes all date-only
 * calculations immune to time-zone and DST shifts.
 */

import { GregorianDate, JalaliDate } from "./types";

const BREAKS: readonly number[] = [
    -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210,
    1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
];

/** Supported Jalali year range for the fallback algorithm. */
export const MIN_JALALI_YEAR = 1;
export const MAX_JALALI_YEAR = 3177;

function div(a: number, b: number): number {
    return Math.trunc(a / b);
}

function mod(a: number, b: number): number {
    return a - Math.trunc(a / b) * b;
}

interface JalCalResult {
    /** 0 = leap year; 1..4 = years since last leap year. */
    leap: number;
    gy: number;
    /** Day of March (Gregorian) on which Farvardin 1 falls. */
    march: number;
}

function jalCal(jy: number): JalCalResult {
    const bl = BREAKS.length;
    const gy = jy + 621;
    let leapJ = -14;
    let jp = BREAKS[0];
    let jump = 0;

    if (jy < jp || jy >= BREAKS[bl - 1]) {
        throw new RangeError(`Jalali year out of supported range: ${jy}`);
    }
    for (let i = 1; i < bl; i += 1) {
        const jm = BREAKS[i];
        jump = jm - jp;
        if (jy < jm) {
            break;
        }
        leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
        jp = jm;
    }
    let n = jy - jp;
    leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
    if (mod(jump, 33) === 4 && jump - n === 4) {
        leapJ += 1;
    }
    const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
    const march = 20 + leapJ - leapG;

    if (jump - n < 6) {
        n = n - jump + div(jump + 4, 33) * 33;
    }
    let leap = mod(mod(n + 1, 33) - 1, 4);
    if (leap === -1) {
        leap = 4;
    }
    return { leap, gy, march };
}

/** Gregorian (proleptic) calendar date -> Julian Day Number. */
export function gregorianToDayNumber(gy: number, gm: number, gd: number): number {
    let d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4)
        + div(153 * mod(gm + 9, 12) + 2, 5)
        + gd - 34840408;
    d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
    return d;
}

/** Julian Day Number -> Gregorian calendar date. */
export function dayNumberToGregorian(jdn: number): GregorianDate {
    let j = 4 * jdn + 139361631;
    j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
    const i = div(mod(j, 1461), 4) * 5 + 308;
    const gd = div(mod(i, 153), 5) + 1;
    const gm = mod(div(i, 153), 12) + 1;
    const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
    return { year: gy, month: gm, day: gd };
}

export function isSupportedJalaliYear(jy: number): boolean {
    return Number.isInteger(jy) && jy >= MIN_JALALI_YEAR && jy <= MAX_JALALI_YEAR;
}

/** True when the Jalali year has 366 days (Esfand has 30 days). */
export function isJalaliLeapYear(jy: number): boolean {
    return jalCal(jy).leap === 0;
}

/** Number of days in a Jalali month according to the fallback algorithm. */
export function jalaliMonthLength(jy: number, jm: number): number {
    if (jm <= 6) {
        return 31;
    }
    if (jm <= 11) {
        return 30;
    }
    return isJalaliLeapYear(jy) ? 30 : 29;
}

/** Structural validation of a Jalali date using the fallback algorithm. */
export function isValidJalaliDate(jy: number, jm: number, jd: number): boolean {
    if (!isSupportedJalaliYear(jy) || !Number.isInteger(jm) || !Number.isInteger(jd)) {
        return false;
    }
    if (jm < 1 || jm > 12 || jd < 1) {
        return false;
    }
    return jd <= jalaliMonthLength(jy, jm);
}

/** Jalali date -> Julian Day Number (fallback algorithm). */
export function jalaliToDayNumber(jy: number, jm: number, jd: number): number {
    const r = jalCal(jy);
    return gregorianToDayNumber(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
}

/** Julian Day Number -> Jalali date (fallback algorithm). */
export function dayNumberToJalali(jdn: number): JalaliDate {
    const gy = dayNumberToGregorian(jdn).year;
    let jy = gy - 621;
    const r = jalCal(jy);
    const farvardin1 = gregorianToDayNumber(gy, 3, r.march);
    let k = jdn - farvardin1;
    if (k >= 0) {
        if (k <= 185) {
            return { year: jy, month: 1 + div(k, 31), day: mod(k, 31) + 1 };
        }
        k -= 186;
    } else {
        jy -= 1;
        k += 179;
        if (r.leap === 1) {
            k += 1;
        }
    }
    return { year: jy, month: 7 + div(k, 30), day: mod(k, 30) + 1 };
}

/**
 * Column index (0..6) in a Saturday-first week for a day number.
 * 0 = Saturday (شنبه) ... 6 = Friday (جمعه).
 * Equals `Dates_Dim[DayOfWeekShamsi] - 1`.
 */
export function saturdayFirstWeekday(jdn: number): number {
    // JDN 0 is a Monday; Saturday ≡ 5 (mod 7).
    return ((jdn + 2) % 7 + 7) % 7;
}
