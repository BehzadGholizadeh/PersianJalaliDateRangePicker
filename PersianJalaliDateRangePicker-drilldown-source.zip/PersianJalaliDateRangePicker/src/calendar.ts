/**
 * Calendar model.
 *
 * PRIMARY SOURCE: rows of Dates_Dim received through the data roles
 *   Date       -> Dates_Dim[MDate]   (Gregorian, used for filtering)
 *   JalaliDate -> Dates_Dim[Date_ID] (Jalali "YYYY/MM/DD", used for display)
 * Each row gives an authoritative (Jalali date <-> Gregorian day) pair.
 *
 * FALLBACK: for any day/month not present in the received rows (outside the
 * model's range, data reduction, cross-filtering by another slicer, or the
 * JalaliDate role not bound) the arithmetic algorithm in jalali.ts is used.
 * The fallback never overrides a mapping that came from the data.
 */
import { dateValueToDayNumber, jalaliKey, parseJalaliValue } from "./date-utils";
import {
    dayNumberToJalali,
    isSupportedJalaliYear,
    isValidJalaliDate,
    jalaliMonthLength,
    jalaliToDayNumber,
    saturdayFirstWeekday
} from "./jalali";
import { JalaliDate } from "./types";

export interface CalendarRow {
    date: unknown;
    jalali?: unknown;
}

export interface CalendarCell {
    /** Position 0..41 in the 6x7 grid (Saturday-first). */
    index: number;
    /** Day number, or null for a blank padding cell. */
    day: number | null;
    jalali: JalaliDate | null;
    /** True when this exact day was received from Dates_Dim. */
    inData: boolean;
}

export interface MonthView {
    year: number;
    month: number;
    cells: CalendarCell[];
    /** Number of days in this month (from data when complete, else fallback). */
    length: number;
}

export interface BuildStats {
    rows: number;
    accepted: number;
    malformed: number;
    /** Rows whose Date_ID disagrees with the fallback algorithm (data wins). */
    disagreements: number;
}

export const GRID_CELLS = 42;

export class CalendarModel {
    private readonly jalaliToDay = new Map<number, number>();
    private readonly dayToJalali = new Map<number, JalaliDate>();
    private readonly dayPresent = new Set<number>();
    private readonly monthMaxDay = new Map<number, number>(); // y*100+m -> max day seen
    public readonly stats: BuildStats = { rows: 0, accepted: 0, malformed: 0, disagreements: 0 };
    public minDay: number | null = null;
    public maxDay: number | null = null;
    /** True when at least one row supplied a Jalali value from the model. */
    public hasJalaliData = false;

    public static fromRows(rows: Iterable<CalendarRow>): CalendarModel {
        const model = new CalendarModel();
        for (const row of rows) {
            model.addRow(row);
        }
        return model;
    }

    private addRow(row: CalendarRow): void {
        this.stats.rows += 1;
        const day = dateValueToDayNumber(row.date);
        if (day === null) {
            this.stats.malformed += 1;
            return;
        }
        let jal: JalaliDate | null = null;
        if (row.jalali !== undefined && row.jalali !== null) {
            jal = parseJalaliValue(row.jalali);
            if (jal === null) {
                this.stats.malformed += 1; // malformed Date_ID: fall back for this day
            }
        }
        const fallback = safeDayToJalali(day);
        if (jal === null) {
            jal = fallback;
            if (jal === null) {
                this.stats.malformed += 1;
                return;
            }
        } else {
            this.hasJalaliData = true;
            if (fallback && (fallback.year !== jal.year || fallback.month !== jal.month || fallback.day !== jal.day)) {
                this.stats.disagreements += 1;
            }
        }
        // First mapping for a given key wins (duplicate rows from DateTime values are harmless).
        const key = jalaliKey(jal.year, jal.month, jal.day);
        if (!this.jalaliToDay.has(key)) {
            this.jalaliToDay.set(key, day);
        }
        if (!this.dayToJalali.has(day)) {
            this.dayToJalali.set(day, jal);
        }
        this.dayPresent.add(day);
        const mk = jal.year * 100 + jal.month;
        this.monthMaxDay.set(mk, Math.max(this.monthMaxDay.get(mk) ?? 0, jal.day));
        this.minDay = this.minDay === null ? day : Math.min(this.minDay, day);
        this.maxDay = this.maxDay === null ? day : Math.max(this.maxDay, day);
        this.stats.accepted += 1;
    }

    public get isEmpty(): boolean {
        return this.stats.accepted === 0;
    }

    public isInData(day: number): boolean {
        return this.dayPresent.has(day);
    }

    /** Day number -> Jalali date (data first, then fallback). */
    public toJalali(day: number): JalaliDate | null {
        return this.dayToJalali.get(day) ?? safeDayToJalali(day);
    }

    /** Jalali date -> day number (data first, then fallback). Null if not a valid date. */
    public toDay(y: number, m: number, d: number): number | null {
        const fromData = this.jalaliToDay.get(jalaliKey(y, m, d));
        if (fromData !== undefined) {
            return fromData;
        }
        if (d > this.monthLength(y, m)) {
            return null;
        }
        return safeJalaliToDay(y, m, d);
    }

    /**
     * Month length. Uses the data when the month is known to be complete in the
     * received rows (i.e. the following month's day 1 is present too); this
     * honours Dates_Dim's own Esfand 29/30 (KabiseYear) definition.
     * Otherwise uses max(data, fallback) so no real day is ever hidden.
     */
    public monthLength(y: number, m: number): number {
        const fallback = isSupportedJalaliYear(y) ? jalaliMonthLength(y, m) : 31;
        const dataMax = this.monthMaxDay.get(y * 100 + m);
        if (dataMax === undefined) {
            return fallback;
        }
        const ny = m === 12 ? y + 1 : y;
        const nm = m === 12 ? 1 : m + 1;
        const nextStartKnown = this.jalaliToDay.has(jalaliKey(ny, nm, 1));
        const thisStartKnown = this.jalaliToDay.has(jalaliKey(y, m, 1));
        if (nextStartKnown && thisStartKnown) {
            return dataMax;
        }
        return Math.max(dataMax, fallback);
    }

    /** True when (y, m, d) is a real day according to data or fallback. */
    public isValidDate(y: number, m: number, d: number): boolean {
        if (this.jalaliToDay.has(jalaliKey(y, m, d))) {
            return true;
        }
        if (!isValidJalaliDate(y, m, 1) || d < 1) {
            return false;
        }
        return d <= this.monthLength(y, m);
    }

    /** Builds the fixed 42-cell, Saturday-first grid for a Jalali month. */
    public monthView(y: number, m: number): MonthView {
        const length = this.monthLength(y, m);
        const cells: CalendarCell[] = [];
        const first = this.toDay(y, m, 1);
        const offset = first === null ? 0 : saturdayFirstWeekday(first);
        for (let i = 0; i < GRID_CELLS; i += 1) {
            const d = i - offset + 1;
            if (first === null || d < 1 || d > length) {
                cells.push({ index: i, day: null, jalali: null, inData: false });
                continue;
            }
            const day = this.toDay(y, m, d) ?? first + d - 1;
            cells.push({
                index: i,
                day,
                jalali: { year: y, month: m, day: d },
                inData: this.dayPresent.has(day)
            });
        }
        return { year: y, month: m, cells, length };
    }
}

function safeDayToJalali(day: number): JalaliDate | null {
    try {
        return dayNumberToJalali(day);
    } catch {
        return null;
    }
}

function safeJalaliToDay(y: number, m: number, d: number): number | null {
    try {
        if (!isValidJalaliDate(y, m, d)) {
            return null;
        }
        return jalaliToDayNumber(y, m, d);
    } catch {
        return null;
    }
}

/** Month navigation with year wrap-around (1404/12 -> 1405/01 and back). */
export function addMonths(year: number, month: number, delta: number): { year: number; month: number } {
    const idx = year * 12 + (month - 1) + delta;
    return { year: Math.floor(idx / 12), month: (idx % 12 + 12) % 12 + 1 };
}
