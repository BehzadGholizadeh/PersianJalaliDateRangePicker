/**
 * Pure range-selection logic. All days are Julian Day Numbers (integers).
 * Invariant enforced by every function here: if both ends are set, start <= end.
 */
import { CompleteRange, DayRange } from "./types";

export const EMPTY_RANGE: Readonly<DayRange> = Object.freeze({ start: null, end: null });

function isDay(v: number | null): v is number {
    return typeof v === "number" && Number.isInteger(v);
}

/** Returns a copy with start <= end (swapping if needed). Null ends are preserved. */
export function normalizeRange(range: DayRange): DayRange {
    const start = isDay(range.start) ? range.start : null;
    const end = isDay(range.end) ? range.end : null;
    if (start !== null && end !== null && start > end) {
        return { start: end, end: start };
    }
    if (start === null && end !== null) {
        // An end without a start is treated as a one-day selection.
        return { start: end, end: null };
    }
    return { start, end };
}

/**
 * Returns a complete inclusive range, or null when nothing is selected.
 * A start without an end means the single day `start`.
 */
export function completeRange(range: DayRange): CompleteRange | null {
    const n = normalizeRange(range);
    if (n.start === null) {
        return null;
    }
    const end = n.end === null ? n.start : n.end;
    return { start: n.start, end };
}

/**
 * Click behaviour of the calendar:
 *  - nothing selected, or a complete range exists -> start a new range at `day`
 *  - only start selected -> `day` becomes the other end; reversed clicks are normalized
 */
export function selectDay(range: DayRange, day: number): DayRange {
    const n = normalizeRange(range);
    if (n.start === null || n.end !== null) {
        return { start: day, end: null };
    }
    return normalizeRange({ start: n.start, end: day });
}

/**
 * "Today" button behaviour:
 *  - nothing selected -> start = today
 *  - start but no end -> end = today (normalized)
 *  - complete range   -> start a new range at today
 */
export function applyToday(range: DayRange, today: number): DayRange {
    const n = normalizeRange(range);
    if (n.start === null) {
        return { start: today, end: null };
    }
    if (n.end === null) {
        return normalizeRange({ start: n.start, end: today });
    }
    return { start: today, end: null };
}

export function rangesEqual(a: DayRange | null, b: DayRange | null): boolean {
    const x = a ?? EMPTY_RANGE;
    const y = b ?? EMPTY_RANGE;
    return x.start === y.start && x.end === y.end;
}

export function completeRangesEqual(a: CompleteRange | null, b: CompleteRange | null): boolean {
    if (a === null || b === null) {
        return a === b;
    }
    return a.start === b.start && a.end === b.end;
}

/** True when `day` lies within the inclusive range. */
export function isInRange(range: CompleteRange | null, day: number): boolean {
    return range !== null && day >= range.start && day <= range.end;
}

/** Validates an arbitrary range; returns an error code or null if valid. */
export function validateRange(range: DayRange): "empty" | "reversed" | null {
    if (!isDay(range.start)) {
        return "empty";
    }
    if (isDay(range.end) && range.end < range.start) {
        return "reversed";
    }
    return null;
}
