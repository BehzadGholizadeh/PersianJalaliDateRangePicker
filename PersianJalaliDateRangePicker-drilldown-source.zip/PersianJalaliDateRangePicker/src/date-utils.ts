import { GregorianDate, JalaliDate } from "./types";
import { dayNumberToGregorian, gregorianToDayNumber } from "./jalali";

const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** Converts ASCII digits 0-9 in a string to Persian digits. Other characters are kept. */
export function toPersianDigits(value: string | number): string {
    return String(value).replace(/[0-9]/g, (d) => PERSIAN_DIGITS[d.charCodeAt(0) - 48]);
}

/** Converts Persian (U+06F0..U+06F9) and Arabic-Indic (U+0660..U+0669) digits to ASCII. */
export function toLatinDigits(value: string): string {
    return value
        .replace(/[\u06F0-\u06F9]/g, (d) => String(d.charCodeAt(0) - 0x06F0))
        .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660));
}

function pad2(n: number): string {
    return n < 10 ? `0${n}` : String(n);
}

/** Formats a Jalali date as YYYY{sep}MM{sep}DD, optionally with Persian digits. */
export function formatJalali(date: JalaliDate, separator = "/", persianDigits = true): string {
    const text = `${date.year}${separator}${pad2(date.month)}${separator}${pad2(date.day)}`;
    return persianDigits ? toPersianDigits(text) : text;
}

/**
 * Parses a `Dates_Dim[Date_ID]`-style value into its numeric parts.
 * Accepts "1399/05/07", "1399-5-7", "1399.05.07", "۱۳۹۹/۰۵/۰۷" and the
 * 8-digit forms "13990507" / 13990507 (Date_Int). Returns null when malformed.
 * Only structural checks are done here (month 1..12, day 1..31);
 * calendar validity is decided by the data / fallback (see calendar.ts).
 */
export function parseJalaliValue(value: unknown): JalaliDate | null {
    if (value === null || value === undefined) {
        return null;
    }
    let text: string;
    if (typeof value === "number") {
        if (!Number.isInteger(value)) {
            return null;
        }
        text = String(value);
    } else if (typeof value === "string") {
        text = toLatinDigits(value.trim());
    } else {
        return null;
    }

    let y: number;
    let m: number;
    let d: number;
    const sep = /^(\d{3,4})[/\-.](\d{1,2})[/\-.](\d{1,2})$/.exec(text);
    if (sep) {
        y = Number(sep[1]);
        m = Number(sep[2]);
        d = Number(sep[3]);
    } else if (/^\d{8}$/.test(text)) {
        y = Number(text.slice(0, 4));
        m = Number(text.slice(4, 6));
        d = Number(text.slice(6, 8));
    } else {
        return null;
    }
    if (m < 1 || m > 12 || d < 1 || d > 31 || y < 1) {
        return null;
    }
    return { year: y, month: m, day: d };
}

/**
 * Converts a value received from Power BI for the Date role (Dates_Dim[MDate])
 * into a Julian Day Number WITHOUT any time-zone conversion.
 *
 * Power BI delivers date/datetime columns to visuals as JavaScript Date objects
 * whose LOCAL calendar fields (getFullYear/getMonth/getDate) carry the model's
 * date. We therefore read local fields and never call toISOString()/getUTC*(),
 * which would shift the day for users east/west of UTC (e.g. Iran, UTC+03:30).
 * Any time-of-day part is ignored (DateTime safety).
 *
 * Strings such as "2020/07/28" or "2020-07-28T00:00:00" are parsed naively
 * (by their written Y-M-D), also without time-zone conversion.
 */
export function dateValueToDayNumber(value: unknown): number | null {
    if (value instanceof Date) {
        const t = value.getTime();
        if (Number.isNaN(t)) {
            return null;
        }
        return gregorianToDayNumber(value.getFullYear(), value.getMonth() + 1, value.getDate());
    }
    if (typeof value === "string") {
        const m = /^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})/.exec(toLatinDigits(value.trim()));
        if (!m) {
            return null;
        }
        const g: GregorianDate = { year: Number(m[1]), month: Number(m[2]), day: Number(m[3]) };
        return isValidGregorian(g) ? gregorianToDayNumber(g.year, g.month, g.day) : null;
    }
    if (typeof value === "number" && Number.isInteger(value) && value >= 10000101 && value <= 99991231) {
        // MDATE_Key style yyyymmdd
        const g: GregorianDate = {
            year: Math.trunc(value / 10000),
            month: Math.trunc(value / 100) % 100,
            day: value % 100
        };
        return isValidGregorian(g) ? gregorianToDayNumber(g.year, g.month, g.day) : null;
    }
    return null;
}

export function isValidGregorian(g: GregorianDate): boolean {
    if (!Number.isInteger(g.year) || !Number.isInteger(g.month) || !Number.isInteger(g.day)) {
        return false;
    }
    if (g.month < 1 || g.month > 12 || g.day < 1) {
        return false;
    }
    const back = dayNumberToGregorian(gregorianToDayNumber(g.year, g.month, g.day));
    return back.year === g.year && back.month === g.month && back.day === g.day;
}

/** Today's date in the browser's local calendar, as a day number. */
export function todayDayNumber(now: Date = new Date()): number {
    return gregorianToDayNumber(now.getFullYear(), now.getMonth() + 1, now.getDate());
}

/** Stable key for a Jalali Y/M/D, e.g. 14050631. */
export function jalaliKey(y: number, m: number, d: number): number {
    return y * 10000 + m * 100 + d;
}
