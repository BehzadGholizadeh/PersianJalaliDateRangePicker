/** A Jalali (Shamsi) calendar date. month is 1..12, day is 1..31. */
export interface JalaliDate {
    year: number;
    month: number;
    day: number;
}

/** A Gregorian calendar date (no time, no time zone). month is 1..12. */
export interface GregorianDate {
    year: number;
    month: number;
    day: number;
}

/**
 * A date range expressed as Julian Day Numbers (integers).
 * Both ends are inclusive. `null` means "not selected".
 */
export interface DayRange {
    start: number | null;
    end: number | null;
}

/** A complete, valid range: start <= end, both inclusive. */
export interface CompleteRange {
    start: number;
    end: number;
}

/**
 * How day boundaries are encoded in the Power BI filter condition values.
 * - "local": JavaScript Date at local midnight (default; symmetric with how
 *            Power BI hands Date values to visuals).
 * - "utc":   JavaScript Date at UTC midnight.
 * - "naive": ISO string without offset, e.g. "2026-09-22T00:00:00".
 * See README "Filter date encoding" for when to change this.
 */
export type FilterDateEncoding = "local" | "utc" | "naive";

export type UiLanguage = "fa" | "en";

/** Target of the Power BI filter (table + column of the bound Date field). */
export interface FilterColumnTarget {
    table: string;
    column: string;
}
