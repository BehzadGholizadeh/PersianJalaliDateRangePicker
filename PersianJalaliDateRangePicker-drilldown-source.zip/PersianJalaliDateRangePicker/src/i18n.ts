import { UiLanguage } from "./types";

export interface UiStrings {
    dir: "rtl" | "ltr";
    title: string;
    from: string;
    to: string;
    notSelected: string;
    months: readonly string[];
    weekdays: readonly string[];
    weekdaysShort: readonly string[];
    prevMonth: string;
    nextMonth: string;
    prevYear: string;
    nextYear: string;
    today: string;
    clear: string;
    apply: string;
    cancel: string;
    selectDay: (label: string) => string;
    pending: string;
    appliedLabel: (from: string, to: string) => string;
    msgNoDateField: string;
    msgBadDateField: string;
    msgInvalidDate: string;
    msgReversed: string;
    msgSelectFirst: string;
    msgFilterUnsupported: string;
    msgFilterFailed: string;
    msgExternalFilter: string;
    placeholder: string;
    showMonths: (year: string) => string;
    showYears: string;
    prevYears: string;
    nextYears: string;
    selectMonth: (label: string) => string;
    selectYear: (label: string) => string;
    openEmpty: string;
    openWithRange: (from: string, to: string) => string;
    persianDigits: boolean;
}

const FA_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
const FA_WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];

export const STRINGS: Record<UiLanguage, UiStrings> = {
    fa: {
        dir: "rtl",
        title: "انتخاب بازه زمانی",
        from: "از تاریخ",
        to: "تا تاریخ",
        notSelected: "—",
        months: FA_MONTHS,
        weekdays: FA_WEEKDAYS,
        weekdaysShort: ["ش", "ی", "د", "س", "چ", "پ", "ج"],
        prevMonth: "ماه قبل",
        nextMonth: "ماه بعد",
        prevYear: "سال قبل",
        nextYear: "سال بعد",
        today: "امروز",
        clear: "پاک کردن",
        apply: "اعمال",
        cancel: "انصراف",
        selectDay: (label) => `انتخاب ${label}`,
        pending: "اعمال‌نشده",
        appliedLabel: (from, to) => `بازه اعمال‌شده: ${from} تا ${to}`,
        msgNoDateField: "لطفاً ستون تاریخ را به ویژوال اضافه کنید.",
        msgBadDateField: "ستون تاریخ باید یک ستون (مانند Dates_Dim[MDate]) باشد، نه سنجه یا مقدار تجمیعی.",
        msgInvalidDate: "تاریخ انتخاب‌شده معتبر نیست.",
        msgReversed: "تاریخ پایان نمی‌تواند قبل از تاریخ شروع باشد.",
        msgSelectFirst: "ابتدا تاریخ شروع را انتخاب کنید.",
        msgFilterUnsupported: "این نسخه از Power BI از فیلتر ویژوال پشتیبانی نمی‌کند.",
        msgFilterFailed: "اعمال فیلتر ناموفق بود.",
        msgExternalFilter: "فیلتر موجود روی ستون تاریخ قابل نمایش نیست.",
        placeholder: "انتخاب بازه تاریخ",
        showMonths: (year) => `نمایش ماه‌های سال ${year}`,
        showYears: "نمایش سال‌ها",
        prevYears: "سال‌های قبل",
        nextYears: "سال‌های بعد",
        selectMonth: (label) => `انتخاب ${label}`,
        selectYear: (label) => `انتخاب سال ${label}`,
        openEmpty: "انتخاب بازه تاریخ، باز کردن تقویم",
        openWithRange: (from, to) => `بازه اعمال‌شده ${from} تا ${to}، باز کردن تقویم برای تغییر`,
        persianDigits: true
    },
    en: {
        dir: "ltr",
        title: "Select date range",
        from: "From",
        to: "To",
        notSelected: "—",
        months: ["Farvardin", "Ordibehesht", "Khordad", "Tir", "Mordad", "Shahrivar",
            "Mehr", "Aban", "Azar", "Dey", "Bahman", "Esfand"],
        weekdays: ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        weekdaysShort: ["Sa", "Su", "Mo", "Tu", "We", "Th", "Fr"],
        prevMonth: "Previous month",
        nextMonth: "Next month",
        prevYear: "Previous year",
        nextYear: "Next year",
        today: "Today",
        clear: "Clear",
        apply: "Apply",
        cancel: "Cancel",
        selectDay: (label) => `Select ${label}`,
        pending: "Not applied",
        appliedLabel: (from, to) => `Applied range: ${from} to ${to}`,
        msgNoDateField: "Add a date column (Dates_Dim[MDate]) to the Date field well.",
        msgBadDateField: "The Date field must be a column (e.g. Dates_Dim[MDate]), not a measure or aggregate.",
        msgInvalidDate: "The selected date is not valid.",
        msgReversed: "The end date cannot be before the start date.",
        msgSelectFirst: "Select a start date first.",
        msgFilterUnsupported: "This Power BI host does not support visual filters.",
        msgFilterFailed: "Applying the filter failed.",
        msgExternalFilter: "The existing filter on the date column cannot be displayed.",
        placeholder: "Select date range",
        showMonths: (year) => `Show months of ${year}`,
        showYears: "Show years",
        prevYears: "Previous years",
        nextYears: "Next years",
        selectMonth: (label) => `Select ${label}`,
        selectYear: (label) => `Select year ${label}`,
        openEmpty: "Select date range, open calendar",
        openWithRange: (from, to) => `Applied range ${from} to ${to}, open calendar to change`,
        persianDigits: false
    }
};
