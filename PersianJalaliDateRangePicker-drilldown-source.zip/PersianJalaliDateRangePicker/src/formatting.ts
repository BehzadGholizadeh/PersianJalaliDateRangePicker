/**
 * Visual settings + modern Formatting Model (getFormattingModel, API >= 5.1).
 * Implemented without powerbi-visuals-utils-formattingmodel to avoid coupling
 * the visual to a utils version that may require a newer host.
 */
import powerbi from "powerbi-visuals-api";
import { FilterDateEncoding, UiLanguage } from "./types";

import DataViewObjects = powerbi.DataViewObjects;
import FormattingModel = powerbi.visuals.FormattingModel;
import FormattingCard = powerbi.visuals.FormattingCard;
import FormattingSlice = powerbi.visuals.FormattingSlice;

export interface VisualSettings {
    appearance: { backgroundColor: string; transparency: number; showBorder: boolean; borderColor: string; borderRadius: number; accentColor: string };
    header: { show: boolean; text: string; fontSize: number };
    dateDisplay: { showStart: boolean; showEnd: boolean; fontSize: number; separator: string };
    calendar: { fontSize: number; cellSize: number; monthHeaderSize: number; weekdayHeaderSize: number };
    buttons: { showApply: boolean; showClear: boolean; showToday: boolean; showCancel: boolean; autoApply: boolean; focusModeWhenSmall: boolean };
    localization: { language: UiLanguage };
    advanced: { filterDateEncoding: FilterDateEncoding };
}

export function defaultSettings(): VisualSettings {
    return {
        appearance: { backgroundColor: "#FFFFFF", transparency: 0, showBorder: true, borderColor: "#D3DBDB", borderRadius: 8, accentColor: "#0E7C7B" },
        header: { show: true, text: "", fontSize: 14 },
        dateDisplay: { showStart: true, showEnd: true, fontSize: 14, separator: "/" },
        calendar: { fontSize: 13, cellSize: 34, monthHeaderSize: 14, weekdayHeaderSize: 11 },
        buttons: { showApply: true, showClear: true, showToday: true, showCancel: true, autoApply: false, focusModeWhenSmall: true },
        localization: { language: "fa" },
        advanced: { filterDateEncoding: "local" }
    };
}

type Primitive = string | number | boolean;

function readRaw(objects: DataViewObjects | undefined, obj: string, prop: string): unknown {
    const o = objects?.[obj];
    return o ? (o as Record<string, unknown>)[prop] : undefined;
}

function readBool(objects: DataViewObjects | undefined, obj: string, prop: string, def: boolean): boolean {
    const v = readRaw(objects, obj, prop);
    return typeof v === "boolean" ? v : def;
}

function readNum(objects: DataViewObjects | undefined, obj: string, prop: string, def: number, min: number, max: number): number {
    const v = readRaw(objects, obj, prop);
    if (typeof v !== "number" || !Number.isFinite(v)) {
        return def;
    }
    return Math.min(max, Math.max(min, v));
}

function readText(objects: DataViewObjects | undefined, obj: string, prop: string, def: string, maxLen = 200): string {
    const v = readRaw(objects, obj, prop);
    return typeof v === "string" ? v.slice(0, maxLen) : def;
}

function readColor(objects: DataViewObjects | undefined, obj: string, prop: string, def: string): string {
    const v = readRaw(objects, obj, prop) as { solid?: { color?: unknown } } | undefined;
    const c = v?.solid?.color;
    return typeof c === "string" && c.length > 0 ? c : def;
}

function readEnum<T extends string>(objects: DataViewObjects | undefined, obj: string, prop: string, allowed: readonly T[], def: T): T {
    const v = readRaw(objects, obj, prop);
    return typeof v === "string" && (allowed as readonly string[]).includes(v) ? (v as T) : def;
}

export function readSettings(objects: DataViewObjects | undefined): VisualSettings {
    const d = defaultSettings();
    return {
        appearance: {
            backgroundColor: readColor(objects, "appearance", "backgroundColor", d.appearance.backgroundColor),
            transparency: readNum(objects, "appearance", "transparency", d.appearance.transparency, 0, 100),
            showBorder: readBool(objects, "appearance", "showBorder", d.appearance.showBorder),
            borderColor: readColor(objects, "appearance", "borderColor", d.appearance.borderColor),
            borderRadius: readNum(objects, "appearance", "borderRadius", d.appearance.borderRadius, 0, 40),
            accentColor: readColor(objects, "appearance", "accentColor", d.appearance.accentColor)
        },
        header: {
            show: readBool(objects, "header", "show", d.header.show),
            text: readText(objects, "header", "text", d.header.text),
            fontSize: readNum(objects, "header", "fontSize", d.header.fontSize, 8, 40)
        },
        dateDisplay: {
            showStart: readBool(objects, "dateDisplay", "showStart", d.dateDisplay.showStart),
            showEnd: readBool(objects, "dateDisplay", "showEnd", d.dateDisplay.showEnd),
            fontSize: readNum(objects, "dateDisplay", "fontSize", d.dateDisplay.fontSize, 8, 40),
            separator: readText(objects, "dateDisplay", "separator", d.dateDisplay.separator, 3) || "/"
        },
        calendar: {
            fontSize: readNum(objects, "calendar", "fontSize", d.calendar.fontSize, 8, 32),
            cellSize: readNum(objects, "calendar", "cellSize", d.calendar.cellSize, 16, 80),
            monthHeaderSize: readNum(objects, "calendar", "monthHeaderSize", d.calendar.monthHeaderSize, 8, 32),
            weekdayHeaderSize: readNum(objects, "calendar", "weekdayHeaderSize", d.calendar.weekdayHeaderSize, 7, 24)
        },
        buttons: {
            showApply: readBool(objects, "buttons", "showApply", d.buttons.showApply),
            showClear: readBool(objects, "buttons", "showClear", d.buttons.showClear),
            showToday: readBool(objects, "buttons", "showToday", d.buttons.showToday),
            showCancel: readBool(objects, "buttons", "showCancel", d.buttons.showCancel),
            autoApply: readBool(objects, "buttons", "autoApply", d.buttons.autoApply),
            focusModeWhenSmall: readBool(objects, "buttons", "focusModeWhenSmall", d.buttons.focusModeWhenSmall)
        },
        localization: {
            language: readEnum(objects, "localization", "language", ["fa", "en"] as const, d.localization.language)
        },
        advanced: {
            filterDateEncoding: readEnum(objects, "advanced", "filterDateEncoding", ["local", "utc", "naive"] as const, d.advanced.filterDateEncoding)
        }
    };
}

/* ---------------- Formatting model builders ---------------- */

function toggle(obj: string, prop: string, name: string, value: boolean): FormattingSlice {
    return {
        uid: `${obj}_${prop}`, displayName: name,
        control: { type: powerbi.visuals.FormattingComponent.ToggleSwitch, properties: { descriptor: { objectName: obj, propertyName: prop }, value } }
    };
}

function num(obj: string, prop: string, name: string, value: number, min: number, max: number): FormattingSlice {
    return {
        uid: `${obj}_${prop}`, displayName: name,
        control: {
            type: powerbi.visuals.FormattingComponent.NumUpDown,
            properties: {
                descriptor: { objectName: obj, propertyName: prop }, value,
                options: {
                    minValue: { type: powerbi.visuals.ValidatorType.Min, value: min },
                    maxValue: { type: powerbi.visuals.ValidatorType.Max, value: max }
                }
            }
        }
    };
}

function color(obj: string, prop: string, name: string, value: string): FormattingSlice {
    return {
        uid: `${obj}_${prop}`, displayName: name,
        control: { type: powerbi.visuals.FormattingComponent.ColorPicker, properties: { descriptor: { objectName: obj, propertyName: prop }, value: { value } } }
    };
}

function text(obj: string, prop: string, name: string, value: string, placeholder: string): FormattingSlice {
    return {
        uid: `${obj}_${prop}`, displayName: name,
        control: { type: powerbi.visuals.FormattingComponent.TextInput, properties: { descriptor: { objectName: obj, propertyName: prop }, value, placeholder } }
    };
}

function dropdown(obj: string, prop: string, name: string, value: string): FormattingSlice {
    return {
        uid: `${obj}_${prop}`, displayName: name,
        control: { type: powerbi.visuals.FormattingComponent.Dropdown, properties: { descriptor: { objectName: obj, propertyName: prop }, value } }
    };
}

function card(obj: string, name: string, slices: FormattingSlice[]): FormattingCard {
    return {
        uid: `${obj}_card`,
        displayName: name,
        groups: [{ uid: `${obj}_group`, displayName: name, slices }],
        revertToDefaultDescriptors: slices.map((s) => {
            const props = (s.control as { properties: { descriptor: { objectName: string; propertyName: string } } }).properties;
            return { objectName: props.descriptor.objectName, propertyName: props.descriptor.propertyName };
        })
    };
}

export function buildFormattingModel(s: VisualSettings): FormattingModel {
    return {
        cards: [
            card("appearance", "General", [
                color("appearance", "backgroundColor", "Background", s.appearance.backgroundColor),
                num("appearance", "transparency", "Transparency (%)", s.appearance.transparency, 0, 100),
                toggle("appearance", "showBorder", "Border", s.appearance.showBorder),
                color("appearance", "borderColor", "Border color", s.appearance.borderColor),
                num("appearance", "borderRadius", "Border radius", s.appearance.borderRadius, 0, 40),
                color("appearance", "accentColor", "Accent color", s.appearance.accentColor)
            ]),
            card("header", "Header", [
                toggle("header", "show", "Show title", s.header.show),
                text("header", "text", "Title text", s.header.text, "انتخاب بازه زمانی"),
                num("header", "fontSize", "Font size", s.header.fontSize, 8, 40)
            ]),
            card("dateDisplay", "Date display", [
                toggle("dateDisplay", "showStart", "Show start date", s.dateDisplay.showStart),
                toggle("dateDisplay", "showEnd", "Show end date", s.dateDisplay.showEnd),
                num("dateDisplay", "fontSize", "Font size", s.dateDisplay.fontSize, 8, 40),
                text("dateDisplay", "separator", "Separator", s.dateDisplay.separator, "/")
            ]),
            card("calendar", "Calendar", [
                num("calendar", "fontSize", "Font size", s.calendar.fontSize, 8, 32),
                num("calendar", "cellSize", "Cell size", s.calendar.cellSize, 16, 80),
                num("calendar", "monthHeaderSize", "Month header size", s.calendar.monthHeaderSize, 8, 32),
                num("calendar", "weekdayHeaderSize", "Weekday header size", s.calendar.weekdayHeaderSize, 7, 24)
            ]),
            card("buttons", "Buttons", [
                toggle("buttons", "showApply", "Show Apply (اعمال)", s.buttons.showApply),
                toggle("buttons", "showClear", "Show Clear (پاک کردن)", s.buttons.showClear),
                toggle("buttons", "showToday", "Show Today (امروز)", s.buttons.showToday),
                toggle("buttons", "showCancel", "Show Cancel (انصراف)", s.buttons.showCancel),
                toggle("buttons", "autoApply", "Auto Apply (اعمال خودکار)", s.buttons.autoApply),
                toggle("buttons", "focusModeWhenSmall", "Open in focus mode when visual is small", s.buttons.focusModeWhenSmall)
            ]),
            card("localization", "Localization", [
                dropdown("localization", "language", "Language", s.localization.language)
            ]),
            card("advanced", "Advanced", [
                dropdown("advanced", "filterDateEncoding", "Filter date encoding", s.advanced.filterDateEncoding)
            ])
        ]
    };
}

export type { Primitive };
