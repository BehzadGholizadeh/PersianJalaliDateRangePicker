/**
 * Power BI filter construction / interpretation.
 *
 * Uses the official `powerbi-models` AdvancedFilter (schema
 * http://powerbi.com/product/schema#advanced), applied with
 * IVisualHost.applyJsonFilter — supported since early Visual API versions and
 * available in the targeted API 5.3.0.
 *
 * Semantics (inclusive Jalali range [start, end]):
 *     MDate >= start 00:00   AND   MDate < (end + 1 day) 00:00
 * This includes the whole end day even when MDate is a DateTime.
 */
import { AdvancedFilter, IAdvancedFilter, IFilter, IFilterColumnTarget } from "powerbi-models";
import { dateValueToDayNumber } from "./date-utils";
import { dayNumberToGregorian, gregorianToDayNumber } from "./jalali";
import { CompleteRange, FilterColumnTarget, FilterDateEncoding } from "./types";

/** Minimal shape of DataViewMetadataColumn we rely on. */
export interface ColumnMetadataLike {
    queryName?: string;
    displayName?: string;
}

const ADVANCED_SCHEMA_FRAGMENT = "#advanced";
const FILTER_TYPE_ADVANCED = 0; // powerbi-models FilterType.Advanced

/**
 * Builds the filter target from the metadata of the column bound to the
 * **Date** role (Dates_Dim[MDate]). queryName looks like "Dates_Dim.MDate";
 * the column part is taken from queryName (not displayName) so that renaming
 * the field inside the visual does not break the filter.
 * Returns null when the column cannot be resolved to a plain Table.Column
 * (e.g. an aggregated/implicit measure), so we never emit a wrong filter.
 */
export function resolveFilterTarget(column: ColumnMetadataLike | undefined | null): FilterColumnTarget | null {
    if (!column || typeof column.queryName !== "string") {
        return null;
    }
    const qn = column.queryName.trim();
    if (qn.includes("(")) {
        return null; // aggregation such as Min(Dates_Dim.MDate)
    }
    const dot = qn.indexOf(".");
    if (dot <= 0 || dot === qn.length - 1) {
        return null;
    }
    const table = qn.slice(0, dot);
    const column1 = qn.slice(dot + 1);
    return { table, column: column1 };
}

/** Encodes the midnight that starts `jdn` according to the chosen encoding. */
export function encodeDayBoundary(jdn: number, encoding: FilterDateEncoding): Date | string {
    const g = dayNumberToGregorian(jdn);
    switch (encoding) {
        case "utc":
            return new Date(Date.UTC(g.year, g.month - 1, g.day, 0, 0, 0, 0));
        case "naive": {
            const mm = g.month < 10 ? `0${g.month}` : String(g.month);
            const dd = g.day < 10 ? `0${g.day}` : String(g.day);
            return `${String(g.year).padStart(4, "0")}-${mm}-${dd}T00:00:00`;
        }
        case "local":
        default: {
            const d = new Date(g.year, g.month - 1, g.day, 0, 0, 0, 0);
            // Guard for years 0..99, which the Date constructor maps to 1900+.
            d.setFullYear(g.year);
            return d;
        }
    }
}

/** Decodes a boundary value read back from an existing filter into a day number. */
export function decodeDayBoundary(value: unknown, encoding: FilterDateEncoding): number | null {
    if (value instanceof Date) {
        if (Number.isNaN(value.getTime())) {
            return null;
        }
        if (encoding === "utc") {
            return gregorianToDayNumber(value.getUTCFullYear(), value.getUTCMonth() + 1, value.getUTCDate());
        }
        return dateValueToDayNumber(value);
    }
    if (typeof value === "string") {
        // A string ending in Z / ±hh:mm is an absolute instant (e.g. a Date that
        // went through JSON). Interpret it the same way it was encoded.
        if (/(Z|[+-]\d{2}:?\d{2})$/.test(value.trim())) {
            const d = new Date(value);
            if (Number.isNaN(d.getTime())) {
                return null;
            }
            return encoding === "utc"
                ? gregorianToDayNumber(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate())
                : gregorianToDayNumber(d.getFullYear(), d.getMonth() + 1, d.getDate());
        }
        return dateValueToDayNumber(value);
    }
    return null;
}

/**
 * Builds the JSON filter for an inclusive day range on Dates_Dim[MDate].
 * Throws if the range is invalid — callers validate first; this is a last line of defence.
 */
export function buildRangeFilter(
    target: FilterColumnTarget,
    range: CompleteRange,
    encoding: FilterDateEncoding
): IAdvancedFilter {
    if (!Number.isInteger(range.start) || !Number.isInteger(range.end) || range.start > range.end) {
        throw new RangeError("Invalid range: start must be <= end");
    }
    const columnTarget: IFilterColumnTarget = { table: target.table, column: target.column };
    const filter = new AdvancedFilter(
        columnTarget,
        "And",
        { operator: "GreaterThanOrEqual", value: encodeDayBoundary(range.start, encoding) },
        { operator: "LessThan", value: encodeDayBoundary(range.end + 1, encoding) }
    );
    return filter.toJSON();
}

function sameTarget(a: unknown, t: FilterColumnTarget): boolean {
    if (!a || typeof a !== "object") {
        return false;
    }
    const o = a as { table?: unknown; column?: unknown };
    return o.table === t.table && o.column === t.column;
}

function isAdvanced(f: IFilter): boolean {
    const schema = (f as { $schema?: unknown }).$schema;
    return f.filterType === FILTER_TYPE_ADVANCED
        || (typeof schema === "string" && schema.endsWith(ADVANCED_SCHEMA_FRAGMENT));
}

/**
 * Finds this visual's own filter in `jsonFilters` and converts it back to an
 * inclusive day range. Returns:
 *   - a CompleteRange when a filter on exactly our target can be interpreted;
 *   - null when there is no filter on our target, or it cannot be interpreted
 *     safely (unknown shape, other operators, reversed bounds) — the visual
 *     then shows a neutral state and never crashes.
 */
export function parseRangeFilter(
    filters: readonly IFilter[] | null | undefined,
    target: FilterColumnTarget,
    encoding: FilterDateEncoding
): CompleteRange | null {
    if (!Array.isArray(filters)) {
        return null;
    }
    for (const f of filters) {
        try {
            if (!f || !sameTarget((f as { target?: unknown }).target, target) || !isAdvanced(f)) {
                continue;
            }
            const adv = f as IAdvancedFilter;
            if (adv.logicalOperator !== "And" || !Array.isArray(adv.conditions) || adv.conditions.length !== 2) {
                continue;
            }
            const ge = adv.conditions.find((c) => c.operator === "GreaterThanOrEqual");
            const lt = adv.conditions.find((c) => c.operator === "LessThan");
            if (!ge || !lt) {
                continue;
            }
            const start = decodeDayBoundary(ge.value, encoding);
            const endExclusive = decodeDayBoundary(lt.value, encoding);
            if (start === null || endExclusive === null || endExclusive - 1 < start) {
                continue;
            }
            return { start, end: endExclusive - 1 };
        } catch {
            // Malformed payload: ignore and keep looking / fall back to neutral.
        }
    }
    return null;
}

/** True when the given filters contain any filter on our target (interpretable or not). */
export function hasFilterOnTarget(filters: readonly IFilter[] | null | undefined, target: FilterColumnTarget): boolean {
    return Array.isArray(filters) && filters.some((f) => !!f && sameTarget((f as { target?: unknown }).target, target));
}
