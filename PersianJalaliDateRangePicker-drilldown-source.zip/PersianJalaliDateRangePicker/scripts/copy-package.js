// Copies the generated dist/<guid>.<version>.pbiviz to the stable name
// dist/PersianJalaliDateRangePicker.pbiviz required by the deployment docs.
const fs = require("fs");
const path = require("path");
const dist = path.join(__dirname, "..", "dist");
const files = fs.readdirSync(dist)
    .filter((f) => f.endsWith(".pbiviz") && f !== "PersianJalaliDateRangePicker.pbiviz")
    .map((f) => ({ f, t: fs.statSync(path.join(dist, f)).mtimeMs }))
    .sort((a, b) => b.t - a.t);
if (!files.length) {
    console.error("No .pbiviz found in dist/ — did `pbiviz package` succeed?");
    process.exit(1);
}
fs.copyFileSync(path.join(dist, files[0].f), path.join(dist, "PersianJalaliDateRangePicker.pbiviz"));
console.log(`dist/PersianJalaliDateRangePicker.pbiviz <- ${files[0].f}`);
