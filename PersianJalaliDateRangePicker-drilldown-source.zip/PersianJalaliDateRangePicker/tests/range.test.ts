import { test } from "node:test";
import assert from "node:assert/strict";
import { applyToday, completeRange, normalizeRange, selectDay, validateRange, isInRange } from "../src/range";
import { jalaliToDayNumber } from "../src/jalali";

const D10 = jalaliToDayNumber(1405, 6, 10);
const D05 = jalaliToDayNumber(1405, 6, 5);

test("start < end kept", () => {
    assert.deepEqual(normalizeRange({ start: D05, end: D10 }), { start: D05, end: D10 });
});
test("start = end is a valid single day", () => {
    assert.deepEqual(completeRange({ start: D10, end: D10 }), { start: D10, end: D10 });
    assert.equal(validateRange({ start: D10, end: D10 }), null);
});
test("start > end is normalized (swap)", () => {
    assert.deepEqual(normalizeRange({ start: D10, end: D05 }), { start: D05, end: D10 });
    assert.equal(validateRange({ start: D10, end: D05 }), "reversed");
});
test("reverse click order: 10 then 5 -> 5..10", () => {
    let r = selectDay({ start: null, end: null }, D10);
    r = selectDay(r, D05);
    assert.deepEqual(r, { start: D05, end: D10 });
});
test("third click starts a new range", () => {
    const r = selectDay({ start: D05, end: D10 }, D10 + 3);
    assert.deepEqual(r, { start: D10 + 3, end: null });
});
test("null start / null end / both null", () => {
    assert.deepEqual(completeRange({ start: D05, end: null }), { start: D05, end: D05 });
    assert.deepEqual(normalizeRange({ start: null, end: D10 }), { start: D10, end: null });
    assert.equal(completeRange({ start: null, end: null }), null);
    assert.equal(validateRange({ start: null, end: null }), "empty");
});
test("today: empty -> start; start only -> end (normalized); complete -> restart", () => {
    const today = D10;
    assert.deepEqual(applyToday({ start: null, end: null }, today), { start: today, end: null });
    assert.deepEqual(applyToday({ start: D05, end: null }, today), { start: D05, end: today });
    assert.deepEqual(applyToday({ start: today + 4, end: null }, today), { start: today, end: today + 4 });
    assert.deepEqual(applyToday({ start: D05, end: D10 }, today), { start: today, end: null });
});
test("invariant: any click sequence keeps start <= end", () => {
    let r = { start: null as number | null, end: null as number | null };
    let seed = 7;
    for (let i = 0; i < 5000; i++) {
        seed = (seed * 1103515245 + 12345) % 2147483648;
        r = selectDay(r, D05 + (seed % 400) - 200);
        if (r.start !== null && r.end !== null) assert.ok(r.start <= r.end);
    }
});
test("isInRange inclusive bounds", () => {
    const c = { start: D05, end: D10 };
    assert.ok(isInRange(c, D05) && isInRange(c, D10));
    assert.ok(!isInRange(c, D05 - 1) && !isInRange(c, D10 + 1));
});
