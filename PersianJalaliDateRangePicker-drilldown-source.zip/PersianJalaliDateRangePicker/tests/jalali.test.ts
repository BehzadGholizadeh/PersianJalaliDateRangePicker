import { test } from "node:test";
import assert from "node:assert/strict";
import {
    dayNumberToGregorian, dayNumberToJalali, gregorianToDayNumber, isJalaliLeapYear,
    isValidJalaliDate, jalaliMonthLength, jalaliToDayNumber, saturdayFirstWeekday
} from "../src/jalali";
import { formatJalali, parseJalaliValue, toLatinDigits, toPersianDigits, dateValueToDayNumber } from "../src/date-utils";
import { CalendarModel, addMonths } from "../src/calendar";

function j2g(y: number, m: number, d: number): string {
    const g = dayNumberToGregorian(jalaliToDayNumber(y, m, d));
    return `${g.year}-${String(g.month).padStart(2, "0")}-${String(g.day).padStart(2, "0")}`;
}

test("conversion: required reference dates", () => {
    const cases: [number, number, number, string][] = [
        [1399, 5, 7, "2020-07-28"],   // the Dates_Dim example row
        [1403, 12, 30, "2025-03-20"], // 1403 is a leap year
        [1404, 1, 1, "2025-03-21"],
        [1405, 1, 1, "2026-03-21"],
        [1405, 6, 31, "2026-09-22"],
        [1405, 7, 1, "2026-09-23"]
    ];
    for (const [y, m, d, g] of cases) {
        assert.equal(j2g(y, m, d), g, `${y}/${m}/${d}`);
        const back = dayNumberToJalali(jalaliToDayNumber(y, m, d));
        assert.deepEqual(back, { year: y, month: m, day: d });
    }
});

test("conversion: round-trip every day 1300..1500 AP is consecutive and invertible", () => {
    let prev = jalaliToDayNumber(1300, 1, 1) - 1;
    for (let y = 1300; y <= 1500; y++) {
        for (let m = 1; m <= 12; m++) {
            const len = jalaliMonthLength(y, m);
            for (let d = 1; d <= len; d++) {
                const jdn = jalaliToDayNumber(y, m, d);
                assert.equal(jdn, prev + 1, `gap at ${y}/${m}/${d}`);
                prev = jdn;
                const j = dayNumberToJalali(jdn);
                assert.ok(j.year === y && j.month === m && j.day === d);
                const g = dayNumberToGregorian(jdn);
                assert.equal(gregorianToDayNumber(g.year, g.month, g.day), jdn);
            }
        }
    }
});

test("weekday: Saturday-first index matches Dates_Dim DayOfWeekShamsi", () => {
    // 1399/05/07 = Tuesday 2020-07-28, DayOfWeekShamsi = 4
    assert.equal(saturdayFirstWeekday(jalaliToDayNumber(1399, 5, 7)) + 1, 4);
    // 2026-09-19 is a Saturday
    assert.equal(saturdayFirstWeekday(gregorianToDayNumber(2026, 9, 19)), 0);
    // 2026-09-25 is a Friday
    assert.equal(saturdayFirstWeekday(gregorianToDayNumber(2026, 9, 25)), 6);
});

test("leap years: Esfand 30 valid only in leap years", () => {
    for (const y of [1399, 1403, 1408]) {
        assert.equal(isJalaliLeapYear(y), true, `${y} leap`);
        assert.equal(isValidJalaliDate(y, 12, 30), true);
        assert.equal(jalaliMonthLength(y, 12), 30);
    }
    for (const y of [1400, 1401, 1402, 1404, 1405]) {
        assert.equal(isJalaliLeapYear(y), false, `${y} common`);
        assert.equal(isValidJalaliDate(y, 12, 30), false);
        assert.equal(isValidJalaliDate(y, 12, 29), true);
    }
    assert.equal(isValidJalaliDate(1405, 7, 31), false);
    assert.equal(isValidJalaliDate(1405, 13, 1), false);
    assert.equal(isValidJalaliDate(1405, 0, 1), false);
});

test("persian digits", () => {
    assert.equal(toPersianDigits("1405/06/01"), "۱۴۰۵/۰۶/۰۱");
    assert.equal(toPersianDigits(1405), "۱۴۰۵");
    assert.equal(toLatinDigits("۱۴۰۵/۰۶/۰۱"), "1405/06/01");
    assert.equal(toLatinDigits("١٤٠٥"), "1405");
    assert.equal(formatJalali({ year: 1405, month: 6, day: 1 }), "۱۴۰۵/۰۶/۰۱");
    assert.equal(formatJalali({ year: 1405, month: 6, day: 1 }, "-", false), "1405-06-01");
});

test("Date_ID parsing incl. malformed values", () => {
    assert.deepEqual(parseJalaliValue("1399/05/07"), { year: 1399, month: 5, day: 7 });
    assert.deepEqual(parseJalaliValue("۱۳۹۹/۰۵/۰۷"), { year: 1399, month: 5, day: 7 });
    assert.deepEqual(parseJalaliValue(13990507), { year: 1399, month: 5, day: 7 });
    assert.deepEqual(parseJalaliValue("1399-5-7"), { year: 1399, month: 5, day: 7 });
    for (const bad of ["", "abc", "1399/13/01", "1399/00/10", "1399/05/32", null, undefined, 3.5, {}, "1399/05"]) {
        assert.equal(parseJalaliValue(bad as unknown), null, String(bad));
    }
});

test("MDate parsing never shifts the day (local fields, time ignored)", () => {
    const expected = gregorianToDayNumber(2020, 7, 28);
    assert.equal(dateValueToDayNumber(new Date(2020, 6, 28)), expected);
    assert.equal(dateValueToDayNumber(new Date(2020, 6, 28, 23, 59, 59)), expected);
    assert.equal(dateValueToDayNumber("2020/07/28"), expected);
    assert.equal(dateValueToDayNumber("2020-07-28T00:00:00"), expected);
    assert.equal(dateValueToDayNumber(20200728), expected);
    assert.equal(dateValueToDayNumber(new Date(NaN)), null);
    assert.equal(dateValueToDayNumber("2020/02/30"), null);
    assert.equal(dateValueToDayNumber(null), null);
});

test("calendar: data mapping is authoritative over fallback", () => {
    // A (deliberately odd) model that says 1404 has Esfand 30.
    const rows = [];
    for (let d = 1; d <= 29; d++) {
        rows.push({ date: dayNumberToGregorian(jalaliToDayNumber(1404, 12, d)), jalali: `1404/12/${d}` });
    }
    const esf29 = jalaliToDayNumber(1404, 12, 29);
    rows.push({ date: dayNumberToGregorian(esf29 + 1), jalali: "1404/12/30" });
    rows.push({ date: dayNumberToGregorian(esf29 + 2), jalali: "1405/01/01" });
    const model = CalendarModel.fromRows(rows.map(r => ({
        date: `${r.date.year}-${r.date.month}-${r.date.day}`, jalali: r.jalali
    })));
    assert.equal(model.monthLength(1404, 12), 30);
    assert.equal(model.isValidDate(1404, 12, 30), true);
    assert.equal(model.toDay(1404, 12, 30), esf29 + 1);
    assert.ok(model.stats.disagreements >= 1);
});

test("calendar: fallback when data absent; 42-cell Saturday-first grid", () => {
    const model = CalendarModel.fromRows([]);
    const v = model.monthView(1405, 6); // Shahrivar 1405 starts Sat 2026-08-23
    assert.equal(v.cells.length, 42);
    assert.equal(v.length, 31);
    const first = v.cells.find(c => c.day !== null)!;
    assert.equal(first.index, saturdayFirstWeekday(jalaliToDayNumber(1405, 6, 1)));
    assert.equal(v.cells.filter(c => c.day !== null).length, 31);
    assert.equal(model.monthView(1403, 12).length, 30);
    assert.equal(model.monthView(1404, 12).length, 29);
    assert.equal(model.toDay(1404, 12, 30), null);
});

test("calendar: Date_ID role missing -> derived from MDate", () => {
    const model = CalendarModel.fromRows([{ date: new Date(2020, 6, 28) }]);
    assert.deepEqual(model.toJalali(gregorianToDayNumber(2020, 7, 28)), { year: 1399, month: 5, day: 7 });
    assert.equal(model.hasJalaliData, false);
});

test("calendar: malformed rows do not throw", () => {
    const model = CalendarModel.fromRows([
        { date: "garbage", jalali: "x" }, { date: null }, { date: new Date(2020, 6, 28), jalali: "bad" }
    ]);
    assert.equal(model.stats.accepted, 1);
    assert.equal(model.stats.malformed, 3);
});

test("navigation: month and year wrap-around", () => {
    assert.deepEqual(addMonths(1404, 12, 1), { year: 1405, month: 1 });
    assert.deepEqual(addMonths(1405, 1, -1), { year: 1404, month: 12 });
    assert.deepEqual(addMonths(1405, 6, 12), { year: 1406, month: 6 });
    assert.deepEqual(addMonths(1405, 6, -12), { year: 1404, month: 6 });
});
