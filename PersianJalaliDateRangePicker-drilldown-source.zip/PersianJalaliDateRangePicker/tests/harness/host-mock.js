// Mock Power BI host for browser harness tests. NOT shipped in the visual.
// Builds a Dates_Dim-like dataset using Chromium's own Intl Persian calendar
// (independent from the visual's algorithm) and echoes filters back through
// update({ jsonFilters }) the way Power BI does.
window.H = (() => {
  const fmt = new Intl.DateTimeFormat("en-US-u-ca-persian-nu-latn", { year: "numeric", month: "2-digit", day: "2-digit" });
  function jalaliId(d) {
    const p = Object.fromEntries(fmt.formatToParts(d).map(x => [x.type, x.value]));
    return `${p.year.replace(/\D/g, "")}/${p.month}/${p.day}`;
  }
  function buildRows(fromY, fromM, fromD, days, opts = {}) {
    const dates = [], ids = [];
    for (let i = 0; i < days; i++) {
      const d = new Date(fromY, fromM - 1, fromD + i, opts.withTime ? 13 : 0, opts.withTime ? 45 : 0);
      dates.push(d); ids.push(jalaliId(d));
    }
    return { dates, ids };
  }
  const state = { calls: [], filters: [], visual: null, viewport: { width: 600, height: 400 }, objects: {}, rows: null, noJalali: false, failed: null,
                  focusCalls: [], inFocus: false, savedViewport: null };
  function dataView() {
    if (!state.rows) return { metadata: { columns: [], objects: state.objects }, categorical: { categories: [] } };
    const cats = [{ source: { queryName: "Dates_Dim.MDate", displayName: "MDate", roles: { Date: true }, type: { dateTime: true } }, values: state.rows.dates }];
    if (!state.noJalali) cats.push({ source: { queryName: "Dates_Dim.Date_ID", displayName: "Date_ID", roles: { JalaliDate: true }, type: { text: true } }, values: state.rows.ids });
    return { metadata: { columns: cats.map(c => c.source), objects: state.objects }, categorical: { categories: cats } };
  }
  function update(type = 62, extra = {}) {
    const el = document.getElementById("host");
    if (el) { el.style.width = state.viewport.width + "px"; el.style.height = state.viewport.height + "px"; }
    state.visual.update({ viewport: state.viewport, dataViews: [dataView()], type, operationKind: 0, isInFocus: state.inFocus,
      jsonFilters: state.filters.map(f => structuredClone(f)), ...extra });
  }
  const host = {
    applyJsonFilter(f, obj, prop, action) {
      state.calls.push({ f: f === null ? null : structuredClone(f), obj, prop, action });
      state.filters = action === 1 /* remove */ ? [] : [structuredClone(f)];
      setTimeout(() => update(2), 0); // host echoes a data update with the new jsonFilters
    },
    fetchMoreData: () => false,
    // Focus mode: the host enlarges the visual to the full canvas and sends a resize update.
    switchFocusModeState(on) {
      state.focusCalls.push(on);
      if (on && !state.inFocus) { state.savedViewport = state.viewport; state.viewport = { width: 880, height: 560 }; state.inFocus = true; }
      else if (!on && state.inFocus) { state.viewport = state.savedViewport; state.inFocus = false; }
      setTimeout(() => update(4), 0);
    },
    eventService: { renderingStarted() {}, renderingFinished() {}, renderingFailed(o, r) { state.failed = r; } },
    hostCapabilities: { allowInteractions: true },
    colorPalette: { isHighContrast: false, foreground: { value: "#000" }, background: { value: "#fff" }, foregroundSelected: { value: "#00f" } },
    locale: "fa-IR"
  };
  function create(el) {
    el.replaceChildren();
    state.visual = window.powerbi.visuals.plugins.PersianJalaliDateRangePickerA7C31F0E9B2D4.create({ element: el, host });
    return state.visual;
  }
  return { state, buildRows, jalaliId, update, create, host };
})();
