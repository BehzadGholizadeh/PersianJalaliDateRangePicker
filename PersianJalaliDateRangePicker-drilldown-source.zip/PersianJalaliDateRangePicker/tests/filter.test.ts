import { test } from "node:test";
import assert from "node:assert/strict";
import { buildRangeFilter, decodeDayBoundary, encodeDayBoundary, hasFilterOnTarget, parseRangeFilter, resolveFilterTarget } from "../src/filter";
import { jalaliToDayNumber, gregorianToDayNumber } from "../src/jalali";
import { dateValueToDayNumber } from "../src/date-utils";
import type { IFilter } from "powerbi-models";

// Simulated metadata as Power BI supplies it for the two roles.
const mdateColumn = { queryName: "Dates_Dim.MDate", displayName: "MDate", roles: { Date: true } };
const dateIdColumn = { queryName: "Dates_Dim.Date_ID", displayName: "Date_ID", roles: { JalaliDate: true } };

const START = jalaliToDayNumber(1405, 6, 1);   // 2026-08-23
const END = jalaliToDayNumber(1405, 6, 31);    // 2026-09-22

test("target resolves to Dates_Dim[MDate] and never Date_ID", () => {
    const t = resolveFilterTarget(mdateColumn)!;
    assert.deepEqual(t, { table: "Dates_Dim", column: "MDate" });
    const f = buildRangeFilter(t, { start: START, end: END }, "local");
    assert.equal((f.target as { column: string }).column, "MDate");
    assert.notEqual((f.target as { column: string }).column, "Date_ID");
    assert.ok(!JSON.stringify(f).includes("Date_ID"));
    // Sanity: the Date_ID column would resolve differently, so the visual must only use the Date role.
    assert.equal(resolveFilterTarget(dateIdColumn)!.column, "Date_ID");
});

test("renamed field in visual keeps model column name", () => {
    assert.deepEqual(resolveFilterTarget({ queryName: "Dates_Dim.MDate", displayName: "تاریخ" }), { table: "Dates_Dim", column: "MDate" });
});

test("aggregated / malformed columns are rejected", () => {
    assert.equal(resolveFilterTarget({ queryName: "Min(Dates_Dim.MDate)" }), null);
    assert.equal(resolveFilterTarget({ queryName: "MDate" }), null);
    assert.equal(resolveFilterTarget(undefined), null);
});

test("filter semantics: MDate >= start AND MDate < end + 1 day", () => {
    const t = resolveFilterTarget(mdateColumn)!;
    const f = buildRangeFilter(t, { start: START, end: END }, "local");
    assert.equal(f.$schema, "http://powerbi.com/product/schema#advanced");
    assert.equal(f.filterType, 0);
    assert.equal(f.logicalOperator, "And");
    assert.equal(f.conditions!.length, 2);
    const [ge, lt] = f.conditions!;
    assert.equal(ge.operator, "GreaterThanOrEqual");
    assert.equal(lt.operator, "LessThan");
    assert.equal(dateValueToDayNumber(ge.value), gregorianToDayNumber(2026, 8, 23));
    assert.equal(dateValueToDayNumber(lt.value), gregorianToDayNumber(2026, 9, 23)); // end + 1
    const geDate = ge.value as Date, ltDate = lt.value as Date;
    assert.equal(geDate.getHours() + geDate.getMinutes(), 0);
    assert.equal(ltDate.getHours() + ltDate.getMinutes(), 0);
});

test("DateTime: start day included, end day fully included", () => {
    const t = resolveFilterTarget(mdateColumn)!;
    const f = buildRangeFilter(t, { start: START, end: END }, "local");
    const ge = (f.conditions![0].value as Date).getTime();
    const lt = (f.conditions![1].value as Date).getTime();
    const inRange = (d: Date) => d.getTime() >= ge && d.getTime() < lt;
    assert.ok(inRange(new Date(2026, 7, 23, 0, 0, 0)));        // start 00:00
    assert.ok(inRange(new Date(2026, 8, 22, 0, 0, 0)));        // end 00:00
    assert.ok(inRange(new Date(2026, 8, 22, 23, 59, 59, 999)));// end 23:59:59.999
    assert.ok(!inRange(new Date(2026, 7, 22, 23, 59, 59)));    // day before start
    assert.ok(!inRange(new Date(2026, 8, 23, 0, 0, 0)));       // day after end
});

test("same-day range produces a one-day window", () => {
    const t = resolveFilterTarget(mdateColumn)!;
    const f = buildRangeFilter(t, { start: START, end: START }, "local");
    const ge = dateValueToDayNumber(f.conditions![0].value)!;
    const lt = dateValueToDayNumber(f.conditions![1].value)!;
    assert.equal(lt - ge, 1);
});

test("reversed range is refused (never emitted)", () => {
    const t = resolveFilterTarget(mdateColumn)!;
    assert.throws(() => buildRangeFilter(t, { start: END, end: START }, "local"));
});

test("encodings are day-exact and round-trip", () => {
    for (const enc of ["local", "utc", "naive"] as const) {
        const v = encodeDayBoundary(START, enc);
        assert.equal(decodeDayBoundary(v, enc), START, enc);
        // Also survives a JSON round-trip (how filters may come back in jsonFilters)
        const json = JSON.parse(JSON.stringify({ v })).v;
        assert.equal(decodeDayBoundary(json, enc), START, `${enc} json`);
    }
    assert.equal(encodeDayBoundary(START, "naive"), "2026-08-23T00:00:00");
});

test("existing filter is read back; unrelated filters ignored", () => {
    const t = resolveFilterTarget(mdateColumn)!;
    const own = buildRangeFilter(t, { start: START, end: END }, "local") as unknown as IFilter;
    const other = { $schema: "http://powerbi.com/product/schema#basic", target: { table: "Product", column: "Category" }, filterType: 1, operator: "In", values: ["A"] } as unknown as IFilter;
    assert.deepEqual(parseRangeFilter([other, own], t, "local"), { start: START, end: END });
    assert.equal(parseRangeFilter([other], t, "local"), null);
    assert.equal(hasFilterOnTarget([other], t), false);
    assert.equal(hasFilterOnTarget([other, own], t), true);
});

test("uninterpretable filters on our column -> neutral (null), no throw", () => {
    const t = resolveFilterTarget(mdateColumn)!;
    const weird: unknown[] = [
        { target: t, filterType: 0, logicalOperator: "Or", conditions: [] },
        { target: t, filterType: 0, logicalOperator: "And", conditions: [{ operator: "GreaterThan", value: "x" }, { operator: "LessThan", value: "y" }] },
        { target: t, filterType: 1, operator: "In", values: [new Date()] },
        null, 42
    ];
    assert.equal(parseRangeFilter(weird as IFilter[], t, "local"), null);
    assert.equal(parseRangeFilter(undefined, t, "local"), null);
});
