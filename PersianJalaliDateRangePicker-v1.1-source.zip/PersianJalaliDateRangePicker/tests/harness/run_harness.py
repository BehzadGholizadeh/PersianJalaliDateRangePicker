"""
Browser harness for the PACKAGED visual (dist/*.pbiviz) in headless Chromium.
This is NOT Power BI: it uses a mock host (host-mock.js). It verifies DOM,
the collapsed/expanded state machine, keyboard, responsive layout and the exact
filter payloads handed to IVisualHost.applyJsonFilter.
Run:  python3 tests/harness/run_harness.py      (HARNESS_TZ=UTC to change zone)
"""
import glob, json, os, sys, zipfile, datetime
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
pkg = os.path.join(ROOT, "dist", "PersianJalaliDateRangePicker.pbiviz")
with zipfile.ZipFile(pkg) as z:
    res = json.loads(z.read([n for n in z.namelist() if n.startswith("resources/") and n.endswith(".json")][0]))
JS, CSS = res["content"]["js"], res["content"]["css"]
MOCK = open(os.path.join(os.path.dirname(__file__), "host-mock.js"), encoding="utf-8").read()
TZ = os.environ.get("HARNESS_TZ", "Asia/Tehran")
SHOTS = os.path.join(ROOT, "tests", "harness", "screenshots")
os.makedirs(SHOTS, exist_ok=True)
for f in glob.glob(os.path.join(SHOTS, "*.png")):
    os.remove(f)

results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail and not cond else ""))

HTML = f"""<!doctype html><html><head><meta charset="utf-8"><style>{CSS}</style>
<style>body{{margin:0;background:#EEF1F1}} #host{{position:relative;width:600px;height:400px}}</style></head>
<body><div id="host"></div><script>window.powerbi={{}};</script><script>{JS}</script><script>{MOCK}</script></body></html>"""

ARROW = "←"  # RTL: start (right) -> end (left)

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(timezone_id=TZ, locale="fa-IR", viewport={"width": 960, "height": 720})
    page = ctx.new_page()
    errors, requests = [], []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("request", lambda r: requests.append(r.url))
    page.clock.install(time=datetime.datetime(2026, 10, 5, 6, 30, tzinfo=datetime.timezone.utc))  # 1405/07/13
    page.set_content(HTML)

    def setup(w=600, h=400, objects=None, rows=True, no_jalali=False, filters=None, with_time=False, open_=True):
        page.evaluate("""([w,h,objects,rows,noJ,filters,withTime]) => {
            H.state.viewport={width:w,height:h}; H.state.objects=objects||{}; H.state.noJalali=noJ;
            H.state.calls=[]; H.state.filters=filters||[]; H.state.failed=null; H.state.focusCalls=[]; H.state.inFocus=false;
            H.state.rows = rows ? H.buildRows(2024,3,20,1170,{withTime}) : null;
            H.create(document.getElementById('host')); H.update(62);
        }""", [w, h, objects or {}, rows, no_jalali, filters, with_time])
        page.wait_for_timeout(20)
        if open_ and rows:
            open_picker()

    q = lambda sel: page.locator(f"#host {sel}")
    txt = lambda sel: q(sel).first.inner_text().strip()
    is_open = lambda: page.evaluate("!document.querySelector('#host .pjdp-body').hidden && document.querySelector('#host .pjdp-summary').hidden")
    is_collapsed = lambda: page.evaluate("document.querySelector('#host .pjdp-body').hidden && !document.querySelector('#host .pjdp-summary').hidden")
    summary = lambda: page.evaluate("document.querySelector('#host .pjdp-summary-text').textContent")
    fields = lambda: page.evaluate("[...document.querySelectorAll('#host .pjdp-field-value')].map(e=>e.textContent)")
    def open_picker():
        page.click("#host button.pjdp-summary"); page.wait_for_timeout(25)
    def click_day(label):
        page.click(f'#host button.pjdp-cell[aria-label="انتخاب {label}"]'); page.wait_for_timeout(15)
    def click_btn(name):
        page.click(f'#host button.pjdp-btn:text-is("{name}")'); page.wait_for_timeout(25)
    def nav(label, times=1):
        for _ in range(times):
            page.click(f'#host button[aria-label="{label}"]'); page.wait_for_timeout(5)
    calls = lambda: page.evaluate("H.state.calls.length")
    def last_call():
        return page.evaluate("""() => { const c = H.state.calls.at(-1); if (!c) return null; if (!c.f) return {remove:true, action:c.action, obj:c.obj};
            const fmt = d => d instanceof Date ? `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${d.getHours()}:${d.getMinutes()}` : String(d);
            return { target:c.f.target, op:c.f.logicalOperator, obj:c.obj, prop:c.prop, action:c.action,
              conds:c.f.conditions.map(x=>[x.operator, fmt(x.value)]), schema:c.f.$schema, isDate: c.f.conditions.every(x=>x.value instanceof Date) }; }""")
    def shot(name, w=600, h=400):
        page.screenshot(path=f"{SHOTS}/{name}.png", clip={"x": 0, "y": 0, "width": w, "height": h})
    SEP = ["GreaterThanOrEqual", "2026-08-23 0:0"], ["LessThan", "2026-09-23 0:0"]
    MEHR = ["GreaterThanOrEqual", "2026-09-23 0:0"], ["LessThan", "2026-10-08 0:0"]

    # =================== USER ACCEPTANCE TESTS (collapsed/expanded) ===================
    # ---- Test 1 ----
    setup(open_=False)
    check("T1 initial: collapsed, placeholder 'انتخاب بازه تاریخ'", is_collapsed() and summary() == "انتخاب بازه تاریخ", summary())
    check("T1 initial: calendar not on screen", not q(".pjdp-grid").is_visible())
    check("T1 initial: no filter applied", calls() == 0)
    check("T1 initial: frame is transparent, only the control is drawn",
          page.evaluate("getComputedStyle(document.querySelector('#host .pjdp')).backgroundColor") == "rgba(0, 0, 0, 0)")
    shot("T1a_collapsed_empty", 600, 120)
    open_picker()
    check("T1 click -> calendar opens", is_open() and q(".pjdp-grid").is_visible())
    nav("ماه قبل"); click_day("۱۴۰۵/۰۶/۰۱"); click_day("۱۴۰۵/۰۶/۳۱")
    check("T1 selection not yet applied", calls() == 0)
    shot("T1b_expanded_selecting")
    click_btn("اعمال")
    c = last_call()
    check("T1 Apply -> one filter on Dates_Dim[MDate] = [2026-08-23, 2026-09-23)",
          calls() == 1 and c["target"] == {"table": "Dates_Dim", "column": "MDate"} and tuple(c["conds"]) == SEP, str(c))
    check(f"T1 Apply -> collapsed showing ۱۴۰۵/۰۶/۰۱ {ARROW} ۱۴۰۵/۰۶/۳۱",
          is_collapsed() and summary() == f"۱۴۰۵/۰۶/۰۱  {ARROW}  ۱۴۰۵/۰۶/۳۱", summary())
    check("T1 calendar hidden after Apply", not q(".pjdp-grid").is_visible())
    shot("T1c_collapsed_applied", 600, 120)

    # ---- Test 2 ----
    open_picker()
    check("T2 reopen -> calendar shows the applied month (Shahrivar 1405)", is_open() and txt(".pjdp-month") == "شهریور ۱۴۰۵", txt(".pjdp-month"))
    check("T2 reopen -> applied range preselected", fields() == ["۱۴۰۵/۰۶/۰۱", "۱۴۰۵/۰۶/۳۱"] and q(".pjdp-cell--in").count() == 31, str(fields()))
    check("T2 reopen -> nothing re-applied", calls() == 1)
    check("T2 keyboard focus moved into the calendar", page.evaluate("document.activeElement.classList.contains('pjdp-cell')"))

    # ---- Test 3 ----
    nav("ماه بعد"); click_day("۱۴۰۵/۰۷/۰۱"); click_day("۱۴۰۵/۰۷/۱۵")
    check("T3 pending change: Power BI still has the old filter (no call)", calls() == 1 and page.evaluate("H.state.filters.length") == 1)
    check("T3 pending change: old range marked, pending cue shown", q(".pjdp-pending").is_visible())
    click_btn("اعمال")
    c = last_call()
    check("T3 Apply -> new filter [2026-09-23, 2026-10-08)", calls() == 2 and tuple(c["conds"]) == MEHR, str(c and c["conds"]))
    check(f"T3 collapsed showing ۱۴۰۵/۰۷/۰۱ {ARROW} ۱۴۰۵/۰۷/۱۵", is_collapsed() and summary() == f"۱۴۰۵/۰۷/۰۱  {ARROW}  ۱۴۰۵/۰۷/۱۵", summary())

    # ---- Test 4 ----
    open_picker(); click_day("۱۴۰۵/۰۷/۰۳"); click_day("۱۴۰۵/۰۷/۰۹")
    click_btn("انصراف")
    check("T4 انصراف -> collapsed, previous range shown", is_collapsed() and summary() == f"۱۴۰۵/۰۷/۰۱  {ARROW}  ۱۴۰۵/۰۷/۱۵", summary())
    check("T4 انصراف -> no new filter", calls() == 2)
    open_picker()
    check("T4 reopen after cancel shows applied (not discarded) range", fields() == ["۱۴۰۵/۰۷/۰۱", "۱۴۰۵/۰۷/۱۵"], str(fields()))
    click_day("۱۴۰۵/۰۷/۲۰"); page.keyboard.press("Escape"); page.wait_for_timeout(20)
    check("T4 Escape behaves like انصراف", is_collapsed() and calls() == 2 and summary() == f"۱۴۰۵/۰۷/۰۱  {ARROW}  ۱۴۰۵/۰۷/۱۵", summary())
    check("T4 focus returns to the range control", page.evaluate("document.activeElement.classList.contains('pjdp-summary')"))

    # ---- Test 5 ----
    open_picker(); click_btn("پاک کردن")
    c = page.evaluate("H.state.calls.at(-1)")
    check("T5 پاک کردن -> remove action on this visual's general.filter", c["f"] is None and c["action"] == 1 and c["obj"] == "general", str(c))
    check("T5 پاک کردن -> collapsed, 'انتخاب بازه تاریخ'", is_collapsed() and summary() == "انتخاب بازه تاریخ", summary())
    check("T5 host filter list now empty", page.evaluate("H.state.filters.length") == 0)
    open_picker()
    check("T5 reopen after clear: neutral calendar", fields() == ["—", "—"] and q(".pjdp-cell--in").count() == 0, str(fields()))
    check("T5 Clear disabled when nothing to clear", q('button.pjdp-btn:text-is("پاک کردن")').is_disabled())
    n0 = calls()
    page.evaluate("[...document.querySelectorAll('#host button.pjdp-btn')].find(b=>b.textContent==='پاک کردن').click()")
    page.wait_for_timeout(20)
    check("T5 repeated Clear: no extra host call, no error", calls() == n0 and not errors, str(errors[:2]))
    page.keyboard.press("Escape")

    # =================== REGRESSION: existing behaviour ===================
    setup()
    check("R RTL root", q(".pjdp").first.get_attribute("dir") == "rtl")
    check("R opens on current Jalali month (Mehr 1405)", txt(".pjdp-month") == "مهر ۱۴۰۵", txt(".pjdp-month"))
    wd = page.evaluate("[...document.querySelectorAll('#host .pjdp-weekday')].map(e=>e.title)")
    check("R weekdays Saturday-first", wd == ["شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"], str(wd))
    check("R 42 day cells", q(".pjdp-cell").count() == 42)
    check("R Mehr 1 under Wednesday (col 4)", page.evaluate("[...document.querySelectorAll('#host .pjdp-cell')].findIndex(b=>!b.disabled && b.textContent==='۱')") == 4)
    check("R Persian digits", page.evaluate("[...document.querySelectorAll('#host .pjdp-cell')].filter(b=>!b.disabled).every(b=>/^[۰-۹]+$/.test(b.textContent))"))
    check("R today marked", q('button.pjdp-cell--today[aria-label="انتخاب ۱۴۰۵/۰۷/۱۳"]').count() == 1)

    nav("ماه قبل"); click_day("۱۴۰۵/۰۶/۱۰"); click_day("۱۴۰۵/۰۶/۰۵")
    check("R reverse click normalized 05..10", fields() == ["۱۴۰۵/۰۶/۰۵", "۱۴۰۵/۰۶/۱۰"], str(fields()))
    click_btn("اعمال"); c = last_call()
    check("R bounds [2026-08-27, 2026-09-02) as local-midnight Dates", c["conds"] == [["GreaterThanOrEqual","2026-08-27 0:0"],["LessThan","2026-09-02 0:0"]] and c["isDate"], str(c["conds"]))
    check("R advanced schema, And, general.filter, merge", c["schema"].endswith("#advanced") and c["op"] == "And" and c["obj"] == "general" and c["prop"] == "filter" and c["action"] == 0)
    open_picker()
    check("R reopen: Apply enabled (confirm & close)", not q('button.pjdp-btn:text-is("اعمال")').is_disabled())
    check("R reopen: انصراف enabled (always closes)", not q('button.pjdp-btn:text-is("انصراف")').is_disabled())
    n0 = calls()
    click_btn("اعمال")
    check("R Apply of unchanged range: no duplicate filter, collapses", calls() == n0 and is_collapsed())

    open_picker(); click_day("۱۴۰۵/۰۶/۱۵"); click_day("۱۴۰۵/۰۶/۱۵"); click_btn("اعمال"); c = last_call()
    check("R same-day range [d, d+1)", c["conds"] == [["GreaterThanOrEqual","2026-09-06 0:0"],["LessThan","2026-09-07 0:0"]], str(c["conds"]))
    check("R same-day summary shows one date", summary() == "۱۴۰۵/۰۶/۱۵", summary())
    open_picker(); click_day("۱۴۰۵/۰۶/۲۰"); click_btn("اعمال"); c = last_call()
    check("R start only + Apply = single day", c["conds"] == [["GreaterThanOrEqual","2026-09-11 0:0"],["LessThan","2026-09-12 0:0"]], str(c["conds"]))

    setup()
    nav("ماه بعد", 5); check("R forward to Esfand 1405", txt(".pjdp-month") == "اسفند ۱۴۰۵")
    nav("ماه بعد"); check("R Esfand 1405 -> Farvardin 1406", txt(".pjdp-month") == "فروردین ۱۴۰۶")
    nav("ماه قبل"); nav("سال قبل"); check("R year back -> Esfand 1404", txt(".pjdp-month") == "اسفند ۱۴۰۴")
    check("R Esfand 1404 = 29 days", page.evaluate("[...document.querySelectorAll('#host .pjdp-cell')].filter(b=>!b.disabled).length") == 29)
    nav("سال قبل"); check("R Esfand 1403 (leap) = 30 days", page.evaluate("[...document.querySelectorAll('#host .pjdp-cell')].filter(b=>!b.disabled).length") == 30)
    click_day("۱۴۰۳/۱۲/۳۰"); click_btn("اعمال"); c = last_call()
    check("R Esfand 30 1403 -> [2025-03-20, 2025-03-21)", c["conds"] == [["GreaterThanOrEqual","2025-03-20 0:0"],["LessThan","2025-03-21 0:0"]], str(c["conds"]))
    open_picker(); click_day("۱۴۰۳/۱۲/۲۸"); nav("ماه بعد"); click_day("۱۴۰۴/۰۱/۰۳"); click_btn("اعمال"); c = last_call()
    check("R cross-year 1403/12/28..1404/01/03", c["conds"] == [["GreaterThanOrEqual","2025-03-18 0:0"],["LessThan","2025-03-24 0:0"]], str(c["conds"]))

    setup(); nav("ماه قبل", 3); click_btn("امروز")
    check("R Today -> Mehr 1405, start=today, still open, not applied", txt(".pjdp-month") == "مهر ۱۴۰۵" and fields() == ["۱۴۰۵/۰۷/۱۳", "—"] and is_open() and calls() == 0, str(fields()))
    setup(); click_day("۱۴۰۵/۰۷/۲۰"); click_btn("امروز")
    check("R Today as end normalized", fields() == ["۱۴۰۵/۰۷/۱۳", "۱۴۰۵/۰۷/۲۰"] and calls() == 0, str(fields()))

    setup(objects={"buttons": {"autoApply": True}})
    click_day("۱۴۰۵/۰۷/۰۵")
    check("R Auto Apply: first click waits, stays open", calls() == 0 and is_open())
    click_day("۱۴۰۵/۰۷/۰۱"); c = last_call()
    check("R Auto Apply: second click applies normalized range", calls() == 1 and c["conds"] == [["GreaterThanOrEqual","2026-09-23 0:0"],["LessThan","2026-09-28 0:0"]], str(c and c["conds"]))
    check("R Auto Apply: calendar closes after applying", is_collapsed() and summary() == f"۱۴۰۵/۰۷/۰۱  {ARROW}  ۱۴۰۵/۰۷/۰۵", summary())

    existing = page.evaluate("H.state.filters")
    setup(filters=existing, open_=False)
    check("R existing filter shown collapsed on load", is_collapsed() and summary() == f"۱۴۰۵/۰۷/۰۱  {ARROW}  ۱۴۰۵/۰۷/۰۵" and calls() == 0, summary())
    open_picker()
    check("R existing filter preselected on open", fields() == ["۱۴۰۵/۰۷/۰۱", "۱۴۰۵/۰۷/۰۵"], str(fields()))
    weird = [{"$schema": "http://powerbi.com/product/schema#basic", "target": {"table": "Dates_Dim", "column": "MDate"}, "filterType": 1, "operator": "In", "values": [1]}]
    setup(filters=weird, open_=False)
    check("R uninterpretable filter -> neutral placeholder + hint, no crash", summary() == "انتخاب بازه تاریخ" and q(".pjdp-summary").get_attribute("title") != "", summary())
    open_picker()
    check("R Clear available for uninterpretable own filter", not q('button.pjdp-btn:text-is("پاک کردن")').is_disabled())

    setup(rows=False, open_=False)
    check("R missing Date role -> Persian message, no summary", "لطفاً ستون تاریخ" in q(".pjdp-empty").inner_text() and not q(".pjdp-summary").is_visible())
    setup(no_jalali=True)
    check("R no JalaliDate role -> fallback calendar", txt(".pjdp-month") == "مهر ۱۴۰۵")
    page.evaluate("""() => { H.state.rows = { dates:[null,'garbage',new Date(NaN),42,new Date(2026,9,5)], ids:['bad',null,'1405/99/99',{},'1405/07/13'] }; H.update(62); }""")
    page.wait_for_timeout(20)
    check("R malformed values: still open, renders, no failure", is_open() and q(".pjdp-cell").count() == 42 and page.evaluate("H.state.failed") is None)
    setup(with_time=True); nav("ماه قبل"); click_day("۱۴۰۵/۰۶/۳۱"); click_btn("اعمال"); c = last_call()
    check("R DateTime MDate: end day fully included", c["conds"][1] == ["LessThan", "2026-09-23 0:0"], str(c["conds"]))
    setup(objects={"localization": {"language": "en"}}, open_=False)
    check("R English placeholder + LTR", summary() == "Select date range" and q(".pjdp").first.get_attribute("dir") == "ltr", summary())
    open_picker(); check("R English month label", txt(".pjdp-month") == "Mehr 1405")

    # keyboard
    setup(open_=False)
    page.focus("#host button.pjdp-summary"); page.keyboard.press("Enter"); page.wait_for_timeout(20)
    check("K Enter on range control opens calendar", is_open())
    check("K summary has aria-expanded + accessible name", q(".pjdp-summary").get_attribute("aria-label") is not None)
    nav("ماه قبل")
    page.focus('#host button.pjdp-cell[aria-label="انتخاب ۱۴۰۵/۰۶/۱۰"]')
    page.keyboard.press("ArrowLeft")
    check("K RTL ArrowLeft -> next day", page.evaluate("document.activeElement.getAttribute('aria-label')") == "انتخاب ۱۴۰۵/۰۶/۱۱")
    page.keyboard.press("ArrowDown")
    check("K ArrowDown -> +7", page.evaluate("document.activeElement.getAttribute('aria-label')") == "انتخاب ۱۴۰۵/۰۶/۱۸")
    page.keyboard.press("Enter"); page.keyboard.press("ArrowDown"); page.keyboard.press("ArrowDown"); page.keyboard.press("Space")
    check("K Enter/Space across month boundary", fields() == ["۱۴۰۵/۰۶/۱۸", "۱۴۰۵/۰۷/۰۱"], str(fields()))
    check("K one tabbable day", page.evaluate("[...document.querySelectorAll('#host .pjdp-cell')].filter(b=>b.tabIndex===0).length") == 1)
    check("K all visible buttons named", page.evaluate("[...document.querySelectorAll('#host button')].filter(b=>b.offsetParent && !b.disabled).every(b=>(b.getAttribute('aria-label')||b.textContent).trim().length>0)"))
    page.keyboard.press("Escape"); page.wait_for_timeout(15)
    check("K Escape collapses, nothing applied", is_collapsed() and calls() == 0)

    # responsive: expanded
    for (w, h) in [(300, 200), (400, 300), (600, 400), (800, 500)]:
        setup(w, h); nav("ماه قبل"); click_day("۱۴۰۵/۰۶/۰۵"); click_day("۱۴۰۵/۰۶/۱۲")
        m = page.evaluate("""() => { const r=document.querySelector('#host .pjdp');
            const c=[...document.querySelectorAll('#host .pjdp-cell')].find(b=>!b.disabled).getBoundingClientRect();
            return {sw:r.scrollWidth, cw:r.clientWidth, sh:r.scrollHeight, ch:r.clientHeight, cellH:c.height}; }""")
        check(f"S expanded {w}x{h}: no overflow, cells >= 14px", m["sw"] <= m["cw"] and m["sh"] <= m["ch"] + 1 and m["cellH"] >= 14, str(m))
        check(f"S expanded {w}x{h}: no focus mode needed", page.evaluate("H.state.focusCalls.length") == 0)
        shot(f"expanded_{w}x{h}", w, h)
    # responsive: collapsed
    for (w, h) in [(180, 32), (300, 40), (400, 60), (600, 400)]:
        setup(w, h, filters=existing, open_=False)
        m = page.evaluate("""() => { const r=document.querySelector('#host .pjdp'), s=document.querySelector('#host .pjdp-summary').getBoundingClientRect();
            return {sw:r.scrollWidth, cw:r.clientWidth, sh:r.scrollHeight, ch:r.clientHeight, h:s.height, w:s.width}; }""")
        check(f"S collapsed {w}x{h}: control fits frame, compact (<= 44px tall)", m["sw"] <= m["cw"] and m["sh"] <= m["ch"] + 1 and m["h"] <= min(h, 44) + 0.5, str(m))
        shot(f"collapsed_{w}x{h}", w, min(h, 120))

    # small frame -> focus mode
    setup(300, 44, filters=existing, open_=False)
    open_picker(); page.wait_for_timeout(30)
    check("F tiny frame: opening requests focus mode", page.evaluate("H.state.focusCalls") == [True])
    check("F in focus mode the calendar has room", is_open() and page.evaluate("document.querySelector('#host .pjdp-cell').getBoundingClientRect().height") >= 20)
    shot("focus_mode_open", 880, 560)
    nav("ماه قبل"); click_day("۱۴۰۵/۰۶/۰۱"); click_day("۱۴۰۵/۰۶/۳۱"); click_btn("اعمال"); page.wait_for_timeout(30)
    check("F Apply leaves focus mode and collapses", page.evaluate("H.state.focusCalls") == [True, False] and is_collapsed() and tuple(last_call()["conds"]) == SEP)
    open_picker(); page.wait_for_timeout(30); click_day("۱۴۰۵/۰۶/۱۰")
    n0 = calls()
    page.evaluate("() => { H.state.inFocus = false; H.state.viewport = {width:300,height:44}; H.update(4); }"); page.wait_for_timeout(20)
    check("F host 'Back to report' = cancel: collapsed, no filter change", is_collapsed() and calls() == n0 and summary() == f"۱۴۰۵/۰۶/۰۱  {ARROW}  ۱۴۰۵/۰۶/۳۱", summary())
    setup(300, 44, objects={"buttons": {"focusModeWhenSmall": False}}, open_=False); open_picker()
    check("F focus mode disabled by setting: opens inside frame, no host call", is_open() and page.evaluate("H.state.focusCalls.length") == 0)

    page.evaluate("H.host.colorPalette.isHighContrast = true")
    setup(filters=existing, open_=False); check("HC collapsed renders with high-contrast class", q(".pjdp--hc").count() == 1)
    shot("high_contrast_collapsed", 600, 80)
    open_picker(); shot("high_contrast_open")
    page.evaluate("H.host.colorPalette.isHighContrast = false")

    page.evaluate("H.host.hostCapabilities.allowInteractions = false"); setup(open_=False)
    check("I allowInteractions=false: range control disabled", q(".pjdp-summary").is_disabled())
    page.evaluate("document.querySelector('#host .pjdp-summary').click()"); page.wait_for_timeout(15)
    check("I allowInteractions=false: does not open", is_collapsed() and calls() == 0)
    page.evaluate("H.host.hostCapabilities.allowInteractions = true")

    check("No network requests by the visual", len([u for u in requests if not u.startswith(("about:", "data:"))]) == 0, str(requests))
    check("No page/console errors", not errors, str(errors[:3]))
    browser.close()

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)}/{len(results)} harness checks passed (TZ={TZ})")
sys.exit(1 if failed else 0)
