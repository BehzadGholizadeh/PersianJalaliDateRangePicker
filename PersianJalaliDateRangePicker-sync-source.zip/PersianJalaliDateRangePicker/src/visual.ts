"use strict";

import powerbi from "powerbi-visuals-api";
import { IFilter } from "powerbi-models";
import "./../style/visual.less";

import { addMonths, CalendarModel, CalendarRow, GRID_CELLS, MonthView } from "./calendar";
import { formatJalali, toPersianDigits, todayDayNumber } from "./date-utils";
import { buildRangeFilter, hasFilterOnTarget, parseRangeFilter, resolveFilterTarget } from "./filter";
import { buildFormattingModel, defaultSettings, readSettings, VisualSettings } from "./formatting";
import { STRINGS, UiStrings } from "./i18n";
import { dayNumberToJalali, MAX_JALALI_YEAR, MIN_JALALI_YEAR } from "./jalali";
import {
    applyToday, completeRange, completeRangesEqual, EMPTY_RANGE, isInRange,
    normalizeRange, rangesEqual, selectDay
} from "./range";
import { CompleteRange, DayRange, FilterColumnTarget, JalaliDate } from "./types";

import IVisual = powerbi.extensibility.visual.IVisual;
import IVisualHost = powerbi.extensibility.visual.IVisualHost;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import DataView = powerbi.DataView;
import DataViewCategoryColumn = powerbi.DataViewCategoryColumn;

/** Upper bound for fetchMoreData rounds (10,000 rows each). */
const MAX_FETCH_ROUNDS = 20;
/** How long we trust our own just-issued filter over a lagging jsonFilters payload. */
const ISSUE_GRACE_MS = 4000;
/** Below this viewport the expanded calendar is cramped; optionally use Power BI focus mode. */
/** Per-instance DOM id suffix (several pickers can share a page). */
let panelCounter = 0;
const MIN_OPEN_WIDTH = 240;
const MIN_OPEN_HEIGHT = 190;

type MessageKind = "info" | "error";

/** Drill level of the open calendar: days of a month -> months of a year -> a page of years. */
type CalendarView = "day" | "month" | "year";
/** Month and Year views share one 3x4 picker grid (12 months / 12 years). */
const PICK_CELLS = 12;
const YEARS_PER_PAGE = 12;

interface Elements {
    header: HTMLDivElement;
    display: HTMLDivElement;
    fromBox: HTMLDivElement;
    fromLabel: HTMLSpanElement;
    fromValue: HTMLSpanElement;
    toBox: HTMLDivElement;
    toLabel: HTMLSpanElement;
    toValue: HTMLSpanElement;
    pending: HTMLSpanElement;
    prevYear: HTMLButtonElement;
    prevMonth: HTMLButtonElement;
    monthLabel: HTMLDivElement;
    monthPart: HTMLButtonElement;
    yearPart: HTMLButtonElement;
    yearRange: HTMLSpanElement;
    pick: HTMLDivElement;
    pickCells: HTMLButtonElement[];
    nextMonth: HTMLButtonElement;
    nextYear: HTMLButtonElement;
    weekdays: HTMLDivElement[];
    grid: HTMLDivElement;
    cells: HTMLButtonElement[];
    today: HTMLButtonElement;
    clear: HTMLButtonElement;
    cancel: HTMLButtonElement;
    apply: HTMLButtonElement;
    message: HTMLDivElement;
    empty: HTMLDivElement;
    body: HTMLDivElement;
    summary: HTMLButtonElement;
    summaryText: HTMLSpanElement;
}

export class Visual implements IVisual {
    private readonly host: IVisualHost;
    private readonly root: HTMLElement;
    private readonly el: Elements;

    private settings: VisualSettings = defaultSettings();
    private strings: UiStrings = STRINGS.fa;
    private model: CalendarModel = CalendarModel.fromRows([]);
    private lastDataView: DataView | null = null;
    private target: FilterColumnTarget | null = null;
    private jsonFilters: IFilter[] | undefined;

    /** Selection being edited (not yet sent to Power BI unless Auto Apply). */
    private temp: DayRange = { ...EMPTY_RANGE };
    /** Range currently applied to the report (owned filter). */
    private applied: CompleteRange | null = null;

    private view: { year: number; month: number };
    private monthView: MonthView | null = null;
    private viewInitialized = false;
    private focusDay: number | null = null;
    private hoverDay: number | null = null;
    private message: { text: string; kind: MessageKind } | null = null;
    /** Our last own filter change: `before` is what was applied before it (used to recognise host lag). */
    private lastIssued: { range: CompleteRange | null; before: CompleteRange | null; at: number } | null = null;
    private fetchRounds = 0;
    private interactive = true;
    /** Collapsed (range summary only) vs expanded (calendar). */
    private isOpen = false;
    private viewport: powerbi.IViewport = { width: 0, height: 0 };
    /** True while WE put the visual into Power BI focus mode to make room for the calendar. */
    private openedFocusMode = false;
    private sawFocus = false;
    /** Drill-down/up level (only meaningful while open). */
    private calendarView: CalendarView = "day";
    /** First year shown on the Year View page. */
    private yearPageStart = 0;
    /** Keyboard focus position inside the Month/Year picker grid. */
    private pickFocus = 0;

    // `options` is typed optional only because the pbiviz-generated plugin wrapper
    // passes `VisualConstructorOptions | undefined`; Power BI always provides it.
    constructor(options?: VisualConstructorOptions) {
        if (!options?.host || !options.element) {
            throw new Error("Persian Jalali Date Range Picker: missing constructor options");
        }
        this.host = options.host;
        this.root = document.createElement("div");
        this.root.className = "pjdp";
        options.element.appendChild(this.root);
        this.el = this.buildDom();
        const t = dayNumberToJalali(todayDayNumber());
        this.view = { year: t.year, month: t.month };
        this.bindEvents();
        this.showEmpty(this.strings.msgNoDateField);
    }

    /* =============================== Power BI =============================== */

    public update(options: VisualUpdateOptions): void {
        const events = this.host.eventService;
        try {
            events?.renderingStarted(options);
            const dv = options.dataViews?.[0];
            this.settings = readSettings(dv?.metadata?.objects);
            // Hosts that disallow interaction (e.g. some read-only containers) get a display-only picker.
            this.interactive = this.host.hostCapabilities?.allowInteractions !== false;
            this.strings = STRINGS[this.settings.localization.language] ?? STRINGS.fa;
            this.viewport = options.viewport;
            this.trackFocusMode(options.isInFocus);

            if (!dv || dv !== this.lastDataView) {
                this.ingestData(dv, options);
                this.lastDataView = dv ?? null;
            }

            if (!this.target) {
                this.applyStyle(options.viewport);
                this.showEmpty(dv && this.hasDateCategory(dv) ? this.strings.msgBadDateField : this.strings.msgNoDateField);
                events?.renderingFinished(options);
                return;
            }

            if (options.jsonFilters !== undefined) {
                // powerbi.IFilter (API typings) is an opaque marker; the payload is a powerbi-models filter.
                const filters = options.jsonFilters as unknown as IFilter[];
                this.jsonFilters = filters;
                this.syncFromFilters(filters);
            }

            if (!this.viewInitialized) {
                this.viewInitialized = true;
                this.navigateToDay(this.applied?.start ?? todayDayNumber());
            }

            this.hideEmpty();
            this.applyStyle(options.viewport);
            this.render();
            events?.renderingFinished(options);
        } catch (e) {
            // Never let an exception break the report.
            this.setMessage(this.strings.msgInvalidDate, "error");
            events?.renderingFailed(options, e instanceof Error ? e.message : "update failed");
        }
    }

    public getFormattingModel(): powerbi.visuals.FormattingModel {
        return buildFormattingModel(this.settings);
    }

    public destroy(): void {
        this.root.replaceChildren();
    }

    private hasDateCategory(dv: DataView): boolean {
        return (dv.categorical?.categories ?? []).some((c) => !!c.source?.roles?.["Date"]);
    }

    private ingestData(dv: DataView | undefined, options: VisualUpdateOptions): void {
        const cats: DataViewCategoryColumn[] = dv?.categorical?.categories ?? [];
        const dateCat = cats.find((c) => !!c.source?.roles?.["Date"]);
        const jalCat = cats.find((c) => !!c.source?.roles?.["JalaliDate"]);
        if (!dateCat) {
            this.target = null;
            this.model = CalendarModel.fromRows([]);
            return;
        }
        // Filter target comes ONLY from the Date role (Dates_Dim[MDate]); never from Date_ID.
        this.target = resolveFilterTarget(dateCat.source);

        const dates = dateCat.values ?? [];
        const jal = jalCat?.values;
        const rows: CalendarRow[] = new Array(dates.length);
        for (let i = 0; i < dates.length; i += 1) {
            rows[i] = { date: dates[i], jalali: jal ? jal[i] : undefined };
        }
        this.model = CalendarModel.fromRows(rows);

        // Data reduction: page in the rest of Dates_Dim if Power BI segmented it.
        if (options.operationKind === powerbi.VisualDataChangeOperationKind.Create) {
            this.fetchRounds = 0;
        }
        if (dv?.metadata?.segment && this.fetchRounds < MAX_FETCH_ROUNDS) {
            this.fetchRounds += 1;
            try {
                this.host.fetchMoreData(true);
            } catch {
                // Older/limited hosts: the fallback calendar covers missing days.
            }
        }
    }

    /** Reconciles UI state with the filter Power BI reports for this visual. */
    private syncFromFilters(filters: IFilter[]): void {
        if (!this.target) {
            return;
        }
        const enc = this.settings.advanced.filterDateEncoding;
        const parsed = parseRangeFilter(filters, this.target, enc);
        const now = Date.now();

        if (this.lastIssued && now - this.lastIssued.at < ISSUE_GRACE_MS) {
            if (completeRangesEqual(parsed, this.lastIssued.before)
                && !completeRangesEqual(parsed, this.lastIssued.range)) {
                return; // host still shows the pre-change filter (lag): keep our own new state
            }
            // Either the host caught up with our change, or ANOTHER source (e.g. a synced copy of this
            // visual) changed the filter meanwhile: in both cases Power BI's filter state wins below.
        }
        this.lastIssued = null;

        if (!completeRangesEqual(parsed, this.applied)) {
            const dirty = !rangesEqual(this.temp, this.appliedAsRange());
            this.applied = parsed;
            if (!dirty) {
                this.temp = parsed ? { start: parsed.start, end: parsed.end } : { ...EMPTY_RANGE };
                if (parsed && this.viewInitialized) {
                    this.navigateToDay(parsed.start);
                }
            }
        }
        if (!parsed && hasFilterOnTarget(filters, this.target)) {
            this.setMessage(this.strings.msgExternalFilter, "info");
        }
    }

    /* =============================== Actions =============================== */

    private onDayActivated(day: number): void {
        if (!this.interactive) {
            return;
        }
        this.temp = selectDay(this.temp, day);
        this.focusDay = day;
        this.hoverDay = null;
        this.clearMessage();
        if (this.settings.buttons.autoApply && this.temp.end !== null) {
            this.doApply();
            return;
        }
        this.render();
    }

    private doApply(): void {
        if (!this.interactive) {
            return;
        }
        const range = completeRange(normalizeRange(this.temp));
        if (!range) {
            this.setMessage(this.strings.msgSelectFirst, "error");
            this.render();
            return;
        }
        if (range.start > range.end) { // unreachable by construction; defensive
            this.setMessage(this.strings.msgReversed, "error");
            this.render();
            return;
        }
        this.temp = { start: range.start, end: range.end };
        if (!this.target) {
            this.setMessage(this.strings.msgNoDateField, "error");
            this.render();
            return;
        }
        if (completeRangesEqual(range, this.applied)) {
            this.close(); // already applied: do not send a duplicate filter, just collapse
            return;
        }
        if (typeof this.host.applyJsonFilter !== "function") {
            this.setMessage(this.strings.msgFilterUnsupported, "error");
            this.render();
            return;
        }
        try {
            const filter = buildRangeFilter(this.target, range, this.settings.advanced.filterDateEncoding);
            this.host.applyJsonFilter(filter, "general", "filter", powerbi.FilterAction.merge);
            this.lastIssued = { range, before: this.applied, at: Date.now() };
            this.applied = range;
            this.clearMessage();
        } catch {
            this.setMessage(this.strings.msgFilterFailed, "error");
            this.render(); // stay open so the user sees the error
            return;
        }
        this.close();
    }

    private doClear(): void {
        if (!this.interactive) {
            return;
        }
        this.temp = { ...EMPTY_RANGE };
        this.hoverDay = null;
        this.clearMessage();
        const ownFilterExists = this.applied !== null
            || (this.target !== null && hasFilterOnTarget(this.jsonFilters, this.target));
        if (ownFilterExists && typeof this.host.applyJsonFilter === "function") {
            try {
                // Removes ONLY this visual's own filter (general.filter); page/report/other filters are untouched.
                this.host.applyJsonFilter(null as unknown as IFilter, "general", "filter", powerbi.FilterAction.remove);
                this.lastIssued = { range: null, before: this.applied, at: Date.now() };
            } catch {
                this.setMessage(this.strings.msgFilterFailed, "error");
            }
        }
        this.applied = null;
        if (this.message) {
            this.render(); // keep the calendar open to show the failure
            return;
        }
        this.close();
    }

    /** Cancel / Escape: discard the temporary selection, collapse, never touch the Power BI filter. */
    private doCancel(): void {
        this.temp = this.appliedAsRange();
        this.hoverDay = null;
        this.clearMessage();
        if (this.applied) {
            this.navigateToDay(this.applied.start);
        }
        this.close();
    }

    /** Collapsed -> expanded. The calendar starts from the currently applied range. */
    private open(): void {
        if (!this.interactive || this.isOpen) {
            return;
        }
        this.temp = this.appliedAsRange();
        this.hoverDay = null;
        this.clearMessage();
        const anchor = this.applied?.start ?? todayDayNumber();
        this.navigateToDay(anchor);
        this.focusDay = this.applied?.start ?? null;
        this.calendarView = "day";
        this.isOpen = true;
        this.enterFocusModeIfCramped();
        this.render();
        const target = this.el.cells.find((c) => c.tabIndex === 0 && !c.disabled);
        target?.focus();
    }

    /** Expanded -> collapsed. Shows the applied range only. */
    private close(): void {
        const wasOpen = this.isOpen;
        this.isOpen = false;
        this.hoverDay = null;
        this.temp = this.appliedAsRange();
        this.leaveFocusMode();
        this.render();
        if (wasOpen && this.root.contains(document.activeElement)) {
            this.el.summary.focus();
        }
    }

    private enterFocusModeIfCramped(): void {
        const cramped = this.viewport.width < MIN_OPEN_WIDTH || this.viewport.height < MIN_OPEN_HEIGHT;
        if (!cramped || !this.settings.buttons.focusModeWhenSmall || typeof this.host.switchFocusModeState !== "function") {
            return;
        }
        try {
            this.host.switchFocusModeState(true);
            this.openedFocusMode = true;
            this.sawFocus = false;
        } catch {
            this.openedFocusMode = false; // host without focus mode: calendar opens inside the small frame (scrollable)
        }
    }

    private leaveFocusMode(): void {
        if (!this.openedFocusMode) {
            return;
        }
        this.openedFocusMode = false;
        this.sawFocus = false;
        try {
            this.host.switchFocusModeState(false);
        } catch {
            // ignore
        }
    }

    /** If the user leaves the focus mode we opened (host "Back to report"), treat it as Cancel. */
    private trackFocusMode(isInFocus: boolean | undefined): void {
        if (!this.openedFocusMode) {
            return;
        }
        if (isInFocus === true) {
            this.sawFocus = true;
        } else if (isInFocus === false && this.sawFocus) {
            this.openedFocusMode = false;
            this.sawFocus = false;
            if (this.isOpen) {
                this.isOpen = false;
                this.temp = this.appliedAsRange();
                this.hoverDay = null;
            }
        }
    }

    private doToday(): void {
        const today = todayDayNumber();
        this.calendarView = "day";
        this.navigateToDay(today);
        this.focusDay = today;
        this.temp = applyToday(this.temp, today);
        this.clearMessage();
        if (this.settings.buttons.autoApply && this.temp.end !== null) {
            this.doApply();
            return;
        }
        this.render();
    }

    private shiftMonths(delta: number): void {
        const next = addMonths(this.view.year, this.view.month, delta);
        if (next.year < MIN_JALALI_YEAR || next.year > MAX_JALALI_YEAR) {
            return;
        }
        this.view = next;
        this.focusDay = null;
        this.render();
    }

    private navigateToDay(day: number): void {
        const j = this.model.toJalali(day);
        if (j) {
            this.view = { year: j.year, month: j.month };
        }
    }

    private appliedAsRange(): DayRange {
        return this.applied ? { start: this.applied.start, end: this.applied.end } : { ...EMPTY_RANGE };
    }

    private isDirty(): boolean {
        return !rangesEqual(normalizeRange(this.temp), this.appliedAsRange());
    }

    /* =============================== Rendering =============================== */

    private fmt(j: JalaliDate | null): string {
        if (!j) {
            return this.strings.notSelected;
        }
        return formatJalali(j, this.settings.dateDisplay.separator, this.strings.persianDigits);
    }

    private digits(n: number): string {
        return this.strings.persianDigits ? toPersianDigits(n) : String(n);
    }

    private render(): void {
        const s = this.settings;
        const t = this.strings;
        this.root.setAttribute("dir", t.dir);
        this.root.setAttribute("lang", s.localization.language);

        // Collapsed <-> expanded
        this.root.classList.toggle("pjdp--collapsed", !this.isOpen);
        this.el.summary.hidden = this.isOpen;
        this.el.body.hidden = !this.isOpen;
        this.el.summary.setAttribute("aria-expanded", this.isOpen ? "true" : "false");
        this.renderSummary();
        if (!this.isOpen) {
            return; // nothing else is visible; skip calendar work
        }

        // Header
        this.el.header.textContent = s.header.text.trim() || t.title;
        this.el.body.setAttribute("aria-label", this.el.header.textContent);

        // Selected values
        const n = normalizeRange(this.temp);
        this.el.fromLabel.textContent = t.from;
        this.el.toLabel.textContent = t.to;
        this.el.fromValue.textContent = this.fmt(n.start !== null ? this.model.toJalali(n.start) : null);
        this.el.toValue.textContent = this.fmt(n.end !== null ? this.model.toJalali(n.end) : null);
        this.el.fromBox.hidden = !s.dateDisplay.showStart;
        this.el.toBox.hidden = !s.dateDisplay.showEnd;
        const dirty = this.isDirty();
        this.el.pending.textContent = t.pending;
        this.el.pending.hidden = !dirty;
        this.el.display.title = this.applied
            ? t.appliedLabel(this.fmt(this.model.toJalali(this.applied.start)), this.fmt(this.model.toJalali(this.applied.end)))
            : "";

        // Navigation
        const rtl = t.dir === "rtl";
        this.el.prevYear.textContent = rtl ? "»" : "«";
        this.el.prevMonth.textContent = rtl ? "›" : "‹";
        this.el.nextMonth.textContent = rtl ? "‹" : "›";
        this.el.nextYear.textContent = rtl ? "«" : "»";
        this.setLabel(this.el.prevYear, t.prevYear);
        this.setLabel(this.el.prevMonth, t.prevMonth);
        this.setLabel(this.el.nextMonth, t.nextMonth);
        this.setLabel(this.el.nextYear, t.nextYear);
        this.renderDrillHeader();

        // Weekday header
        const full = this.root.classList.contains("pjdp--wide-cells");
        this.el.weekdays.forEach((w, i) => {
            w.textContent = full ? t.weekdays[i] : t.weekdaysShort[i];
            w.title = t.weekdays[i];
        });

        // Footer
        this.el.today.textContent = t.today;
        this.el.clear.textContent = t.clear;
        this.el.cancel.textContent = t.cancel;
        this.el.apply.textContent = t.apply;
        this.el.today.hidden = !s.buttons.showToday;
        this.el.today.disabled = !this.interactive;
        this.el.clear.hidden = !s.buttons.showClear;
        this.el.cancel.hidden = !s.buttons.showCancel;
        this.el.apply.hidden = !s.buttons.showApply;
        // In the collapsed/expanded design Apply also means "confirm and close"; an unchanged
        // range just closes without sending a duplicate filter (see doApply).
        this.el.apply.disabled = !this.interactive || n.start === null;
        this.el.apply.classList.toggle("pjdp-btn--pending", dirty && n.start !== null);
        this.el.cancel.disabled = false; // always closes the calendar
        this.el.clear.disabled = !this.interactive || n.start === null && this.applied === null
            && !(this.target !== null && hasFilterOnTarget(this.jsonFilters, this.target));

        // Message
        this.el.message.textContent = this.message?.text ?? "";
        this.el.message.className = `pjdp-message${this.message ? ` pjdp-message--${this.message.kind}` : ""}`;

        this.renderCells();
        this.renderPick();
    }

    /* ======================= Drill-down / Drill-up ======================= */

    /** Header label + nav buttons for the current drill level. Day View output equals the previous header. */
    private renderDrillHeader(): void {
        const t = this.strings;
        const v = this.calendarView;
        this.root.classList.toggle("pjdp--view-month", v === "month");
        this.root.classList.toggle("pjdp--view-year", v === "year");
        this.el.prevYear.hidden = v !== "day";
        this.el.nextYear.hidden = v !== "day";

        this.el.monthPart.textContent = t.months[this.view.month - 1];
        this.el.monthPart.hidden = v !== "day";
        this.el.monthPart.setAttribute("aria-label", t.showMonths(this.digits(this.view.year)));
        this.el.yearPart.textContent = this.digits(this.view.year);
        this.el.yearPart.hidden = v === "year";
        this.el.yearPart.setAttribute("aria-label", t.showYears);
        const last = this.yearPageStart + YEARS_PER_PAGE - 1;
        this.el.yearRange.textContent = `${this.digits(this.yearPageStart)} – ${this.digits(last)}`;
        this.el.yearRange.hidden = v !== "year";

        if (v === "month") {
            this.setLabel(this.el.prevMonth, t.prevYear);
            this.setLabel(this.el.nextMonth, t.nextYear);
        } else if (v === "year") {
            this.setLabel(this.el.prevMonth, t.prevYears);
            this.setLabel(this.el.nextMonth, t.nextYears);
        }
    }

    /** Fills the 12 picker cells with months (Month View) or years (Year View). */
    private renderPick(): void {
        const v = this.calendarView;
        this.el.pick.hidden = v === "day";
        if (v === "day") {
            return;
        }
        const t = this.strings;
        const sel = completeRange(this.temp);
        const today = this.model.toJalali(todayDayNumber());
        for (let i = 0; i < PICK_CELLS; i += 1) {
            const b = this.el.pickCells[i];
            const cls = ["pjdp-pick-cell"];
            let label: string;
            let first: number | null;
            let last: number | null;
            let current: boolean;
            let isToday: boolean;
            if (v === "month") {
                const m = i + 1;
                b.textContent = t.months[i];
                label = t.selectMonth(`${t.months[i]} ${this.digits(this.view.year)}`);
                first = this.model.toDay(this.view.year, m, 1);
                last = this.model.toDay(this.view.year, m, this.model.monthLength(this.view.year, m));
                current = m === this.view.month;
                isToday = !!today && today.year === this.view.year && today.month === m;
                b.dataset.value = String(m);
            } else {
                const y = this.yearPageStart + i;
                const valid = y >= MIN_JALALI_YEAR && y <= MAX_JALALI_YEAR;
                b.textContent = valid ? this.digits(y) : "";
                label = t.selectYear(this.digits(y));
                first = valid ? this.model.toDay(y, 1, 1) : null;
                last = valid ? this.model.toDay(y, 12, this.model.monthLength(y, 12)) : null;
                current = y === this.view.year;
                isToday = !!today && today.year === y;
                b.dataset.value = String(y);
                b.disabled = !valid;
            }
            if (v === "month") {
                b.disabled = false;
            }
            // Months/years that overlap the (temporary) selected range get the range tint.
            if (sel && first !== null && last !== null && first <= sel.end && last >= sel.start) {
                cls.push("pjdp-pick-cell--in");
            }
            if (current) { cls.push("pjdp-pick-cell--current"); }
            if (isToday) { cls.push("pjdp-pick-cell--today"); }
            b.className = cls.join(" ");
            b.setAttribute("aria-label", label);
            b.setAttribute("aria-pressed", current ? "true" : "false");
            b.tabIndex = i === this.pickFocus ? 0 : -1;
        }
    }

    /** Day -> Month View (click on month name). */
    private drillToMonths(): void {
        this.calendarView = "month";
        this.pickFocus = this.view.month - 1;
        this.render();
        this.focusPick();
    }

    /** Day/Month -> Year View (click on year). The current year sits in the 2nd row, middle. */
    private drillToYears(): void {
        this.calendarView = "year";
        this.yearPageStart = Math.max(MIN_JALALI_YEAR, this.view.year - 4);
        this.pickFocus = this.view.year - this.yearPageStart;
        this.render();
        this.focusPick();
    }

    /** Selecting a picker cell drills down: Year -> Month View, Month -> Day View. */
    private onPickSelected(index: number): void {
        if (this.calendarView === "month") {
            this.view = { year: this.view.year, month: index + 1 };
            this.calendarView = "day";
            this.focusDay = null;
            this.render();
            this.el.cells.find((c) => c.tabIndex === 0 && !c.disabled)?.focus();
        } else if (this.calendarView === "year") {
            const y = this.yearPageStart + index;
            if (y < MIN_JALALI_YEAR || y > MAX_JALALI_YEAR) {
                return;
            }
            this.view = { year: y, month: this.view.month };
            this.calendarView = "month";
            this.pickFocus = this.view.month - 1;
            this.render();
            this.focusPick();
        }
    }

    /** Escape inside Month/Year View goes one level up the drill path back toward Day View. */
    private drillBack(): void {
        if (this.calendarView === "year") {
            this.calendarView = "month";
            this.pickFocus = this.view.month - 1;
            this.render();
            this.focusPick();
        } else if (this.calendarView === "month") {
            this.calendarView = "day";
            this.focusDay = null;
            this.render();
            this.el.cells.find((c) => c.tabIndex === 0 && !c.disabled)?.focus();
        }
    }

    /** ‹ › in Month View = previous/next year; in Year View = previous/next page of years. */
    private onNavStep(delta: -1 | 1): void {
        if (this.calendarView === "month") {
            const y = this.view.year + delta;
            if (y >= MIN_JALALI_YEAR && y <= MAX_JALALI_YEAR) {
                this.view = { year: y, month: this.view.month };
            }
            this.render();
        } else if (this.calendarView === "year") {
            const start = this.yearPageStart + delta * YEARS_PER_PAGE;
            if (start + YEARS_PER_PAGE - 1 >= MIN_JALALI_YEAR && start <= MAX_JALALI_YEAR) {
                this.yearPageStart = start;
            }
            this.render();
        } else {
            this.shiftMonths(delta); // Day View: unchanged behaviour
        }
    }

    private onPickKey(ev: KeyboardEvent): void {
        const rtl = this.strings.dir === "rtl";
        let next = this.pickFocus;
        switch (ev.key) {
            case "ArrowLeft": next += rtl ? 1 : -1; break;
            case "ArrowRight": next += rtl ? -1 : 1; break;
            case "ArrowUp": next -= 3; break;
            case "ArrowDown": next += 3; break;
            case "Home": next = 0; break;
            case "End": next = PICK_CELLS - 1; break;
            default: return;
        }
        ev.preventDefault();
        if (next < 0 || next >= PICK_CELLS) {
            // Moving past the grid edge pages to the previous/next year (Month View) or year page (Year View).
            this.onNavStep(next < 0 ? -1 : 1);
            next = (next + PICK_CELLS) % PICK_CELLS;
        }
        this.pickFocus = next;
        this.renderPick();
        this.focusPick();
    }

    private focusPick(): void {
        this.el.pickCells[this.pickFocus]?.focus();
    }

    private renderSummary(): void {
        const t = this.strings;
        const rtl = t.dir === "rtl";
        let text: string;
        if (this.applied) {
            const from = this.fmt(this.model.toJalali(this.applied.start));
            const to = this.fmt(this.model.toJalali(this.applied.end));
            // In RTL the start date is on the right, so the arrow points left toward the end date.
            text = this.applied.start === this.applied.end ? from : `${from}  ${rtl ? "←" : "→"}  ${to}`;
            this.el.summary.classList.remove("pjdp-summary--empty");
            this.el.summary.setAttribute("aria-label", t.openWithRange(from, to));
        } else {
            text = t.placeholder;
            this.el.summary.classList.add("pjdp-summary--empty");
            this.el.summary.setAttribute("aria-label", t.openEmpty);
        }
        this.el.summaryText.textContent = text;
        this.el.summary.title = this.message?.text ?? "";
        this.el.summary.disabled = !this.interactive;
    }

    private renderCells(): void {
        this.monthView = this.model.monthView(this.view.year, this.view.month);
        const cells = this.monthView.cells;
        const sel = completeRange(this.temp);
        const n = normalizeRange(this.temp);
        const today = todayDayNumber();
        let preview: CompleteRange | null = null;
        if (n.start !== null && n.end === null && this.hoverDay !== null) {
            preview = { start: Math.min(n.start, this.hoverDay), end: Math.max(n.start, this.hoverDay) };
        }
        const dirty = this.isDirty();

        const daysInView = cells.filter((c) => c.day !== null).map((c) => c.day as number);
        let focus = this.focusDay;
        if (focus === null || !daysInView.includes(focus)) {
            const startInView = n.start !== null && daysInView.includes(n.start) ? n.start : null;
            focus = startInView ?? (daysInView.includes(today) ? today : daysInView[0] ?? null);
        }

        for (let i = 0; i < GRID_CELLS; i += 1) {
            const btn = this.el.cells[i];
            const c = cells[i];
            if (c.day === null || c.jalali === null) {
                btn.textContent = "";
                btn.className = "pjdp-cell pjdp-cell--blank";
                btn.disabled = true;
                btn.tabIndex = -1;
                btn.setAttribute("aria-hidden", "true");
                btn.removeAttribute("aria-label");
                btn.removeAttribute("aria-pressed");
                continue;
            }
            const day = c.day;
            const cls = ["pjdp-cell"];
            const inSel = isInRange(sel, day);
            if (inSel) { cls.push("pjdp-cell--in"); }
            if (sel && day === sel.start) { cls.push("pjdp-cell--start"); }
            if (sel && day === sel.end) { cls.push("pjdp-cell--end"); }
            if (!inSel && isInRange(preview, day)) { cls.push("pjdp-cell--preview"); }
            if (day === today) { cls.push("pjdp-cell--today"); }
            if (!c.inData && !this.model.isEmpty) { cls.push("pjdp-cell--nodata"); }
            if (dirty && isInRange(this.applied, day)) { cls.push("pjdp-cell--applied"); }
            const col = i % 7;
            if (col === 6) { cls.push("pjdp-cell--friday"); }
            btn.className = cls.join(" ");
            btn.disabled = false;
            btn.textContent = this.digits(c.jalali.day);
            btn.removeAttribute("aria-hidden");
            btn.setAttribute("aria-label", this.strings.selectDay(this.fmt(c.jalali)));
            btn.setAttribute("aria-pressed", inSel ? "true" : "false");
            btn.tabIndex = day === focus ? 0 : -1;
            btn.dataset.day = String(day);
        }
    }

    private setLabel(btn: HTMLButtonElement, label: string): void {
        btn.setAttribute("aria-label", label);
        btn.title = label;
    }

    private setMessage(text: string, kind: MessageKind): void {
        this.message = { text, kind };
    }

    private clearMessage(): void {
        this.message = null;
    }

    private showEmpty(text: string): void {
        this.el.body.hidden = true;
        this.el.summary.hidden = true;
        this.root.classList.remove("pjdp--collapsed");
        this.el.empty.hidden = false;
        this.el.empty.textContent = text;
        this.root.setAttribute("dir", this.strings.dir);
    }

    private hideEmpty(): void {
        // body/summary visibility is decided by render() from isOpen
        this.el.empty.hidden = true;
    }

    /** Responsive sizing: everything is derived from the viewport; never overflows horizontally. */
    private applyStyle(viewport: powerbi.IViewport): void {
        const s = this.settings;
        const W = Math.max(0, Math.floor(viewport.width));
        const H = Math.max(0, Math.floor(viewport.height));
        const compact = H < 300 || W < 340;
        const tiny = H < 240;
        const pad = compact ? 6 : 10;
        const gap = compact ? 3 : 6;

        const showTitle = s.header.show && !tiny;
        const titleFont = compact ? Math.min(s.header.fontSize, 12) : s.header.fontSize;
        const titleH = showTitle ? Math.ceil(titleFont * 1.5) : 0;
        const showDisplay = s.dateDisplay.showStart || s.dateDisplay.showEnd;
        const dateFont = compact ? Math.min(s.dateDisplay.fontSize, 12) : s.dateDisplay.fontSize;
        const displayH = showDisplay ? Math.ceil(compact ? dateFont * 1.7 : dateFont * 1.5 + 16) : 0;
        const monthFont = compact ? Math.min(s.calendar.monthHeaderSize, 12) : s.calendar.monthHeaderSize;
        const navH = Math.max(compact ? 22 : 28, Math.ceil(monthFont * 2));
        const wdFont = compact ? Math.min(s.calendar.weekdayHeaderSize, 10) : s.calendar.weekdayHeaderSize;
        const wdH = Math.ceil(wdFont * 1.8);
        const anyBtn = s.buttons.showApply || s.buttons.showClear || s.buttons.showToday || s.buttons.showCancel;
        const footerH = anyBtn ? (compact ? 24 : 30) : 0;
        const sections = [titleH, displayH, navH, wdH, footerH].filter((h) => h > 0).length + 1;
        const avail = H - 2 * pad - titleH - displayH - navH - wdH - footerH - gap * (sections - 1);

        const cellW = Math.max(14, Math.floor((W - 2 * pad - 6 * 2) / 7));
        const cellH = Math.max(14, Math.min(s.calendar.cellSize, Math.floor((avail - 5 * 2) / 6)));
        const calFont = Math.max(8, Math.min(s.calendar.fontSize, Math.floor(cellH * 0.55), Math.floor(cellW * 0.5)));

        const r = this.root.style;
        const palette = this.host.colorPalette;
        const hc = palette?.isHighContrast === true;
        const bg = hc ? palette.background.value : toRgba(s.appearance.backgroundColor, 1 - s.appearance.transparency / 100);
        const accent = hc ? palette.foregroundSelected.value : s.appearance.accentColor;
        this.root.classList.toggle("pjdp--hc", hc);
        if (hc) {
            r.setProperty("--pjdp-fg", palette.foreground.value);
        }
        r.setProperty("--pjdp-bg", bg);
        r.setProperty("--pjdp-border", s.appearance.showBorder || hc ? `1px solid ${hc ? palette.foreground.value : s.appearance.borderColor}` : "none");
        r.setProperty("--pjdp-radius", `${s.appearance.borderRadius}px`);
        r.setProperty("--pjdp-accent", accent);
        r.setProperty("--pjdp-accent-soft", hc ? "transparent" : toRgba(accent, 0.14));
        r.setProperty("--pjdp-accent-faint", hc ? "transparent" : toRgba(accent, 0.07));
        r.setProperty("--pjdp-pad", `${pad}px`);
        r.setProperty("--pjdp-gap", `${gap}px`);
        r.setProperty("--pjdp-title-font", `${titleFont}px`);
        r.setProperty("--pjdp-date-font", `${dateFont}px`);
        r.setProperty("--pjdp-month-font", `${monthFont}px`);
        r.setProperty("--pjdp-nav-h", `${navH}px`);
        r.setProperty("--pjdp-wd-font", `${wdFont}px`);
        r.setProperty("--pjdp-wd-h", `${wdH}px`);
        r.setProperty("--pjdp-cell-h", `${cellH}px`);
        r.setProperty("--pjdp-cal-font", `${calFont}px`);
        r.setProperty("--pjdp-footer-h", `${footerH}px`);

        // Collapsed summary: one compact control, sized to fit the frame without horizontal overflow.
        const sumFont = Math.max(9, Math.min(s.dateDisplay.fontSize, Math.floor(H * 0.45), Math.floor((W - 44) / 13)));
        const sumH = Math.max(Math.min(H, 24), Math.min(H, Math.ceil(sumFont * 2.5)));
        r.setProperty("--pjdp-summary-font", `${sumFont}px`);
        r.setProperty("--pjdp-summary-h", `${sumH}px`);
        this.root.classList.toggle("pjdp--compact", compact);
        this.root.classList.toggle("pjdp--wide-cells", cellW >= (this.settings.localization.language === "fa" ? 64 : 76));
        this.el.header.hidden = !showTitle;
        this.el.display.hidden = !showDisplay;
    }

    /* =============================== DOM =============================== */

    private buildDom(): Elements {
        const mk = <K extends keyof HTMLElementTagNameMap>(tag: K, cls: string, parent: HTMLElement): HTMLElementTagNameMap[K] => {
            const e = document.createElement(tag);
            e.className = cls;
            parent.appendChild(e);
            return e;
        };
        const btn = (cls: string, parent: HTMLElement): HTMLButtonElement => {
            const b = mk("button", cls, parent);
            b.type = "button";
            return b;
        };

        const empty = mk("div", "pjdp-empty", this.root);
        empty.setAttribute("role", "status");

        const summary = btn("pjdp-summary", this.root);
        summary.setAttribute("aria-haspopup", "dialog");
        summary.setAttribute("aria-controls", `pjdp-panel-${++panelCounter}`);
        summary.appendChild(calendarIcon());
        const summaryText = mk("span", "pjdp-summary-text", summary);

        const body = mk("div", "pjdp-body", this.root);
        body.id = summary.getAttribute("aria-controls") ?? "";
        body.setAttribute("role", "dialog");
        body.hidden = true;

        const header = mk("div", "pjdp-title", body);
        header.setAttribute("role", "heading");
        header.setAttribute("aria-level", "2");

        const display = mk("div", "pjdp-display", body);
        const fromBox = mk("div", "pjdp-field", display);
        const fromLabel = mk("span", "pjdp-field-label", fromBox);
        const fromValue = mk("span", "pjdp-field-value", fromBox);
        const toBox = mk("div", "pjdp-field", display);
        const toLabel = mk("span", "pjdp-field-label", toBox);
        const toValue = mk("span", "pjdp-field-value", toBox);
        const pending = mk("span", "pjdp-pending", display);

        const nav = mk("div", "pjdp-nav", body);
        const prevYear = btn("pjdp-nav-btn pjdp-nav-btn--year", nav);
        const prevMonth = btn("pjdp-nav-btn", nav);
        const monthLabel = mk("div", "pjdp-month", nav);
        monthLabel.setAttribute("aria-live", "polite");
        // Day View header "مهر ۱۴۰۵": month and year are separately clickable (drill-up).
        const monthPart = btn("pjdp-drill", monthLabel);
        monthLabel.appendChild(document.createTextNode(" "));
        const yearPart = btn("pjdp-drill", monthLabel);
        const yearRange = mk("span", "pjdp-year-range", monthLabel);
        const nextMonth = btn("pjdp-nav-btn", nav);
        const nextYear = btn("pjdp-nav-btn pjdp-nav-btn--year", nav);

        const wdRow = mk("div", "pjdp-weekdays", body);
        wdRow.setAttribute("aria-hidden", "true");
        const weekdays: HTMLDivElement[] = [];
        for (let i = 0; i < 7; i += 1) {
            weekdays.push(mk("div", `pjdp-weekday${i === 6 ? " pjdp-weekday--friday" : ""}`, wdRow));
        }

        const grid = mk("div", "pjdp-grid", body);
        grid.setAttribute("role", "group");
        const cells: HTMLButtonElement[] = [];
        for (let i = 0; i < GRID_CELLS; i += 1) {
            const c = btn("pjdp-cell", grid);
            c.dataset.index = String(i);
            cells.push(c);
        }

        // Month View (12 months) / Year View (12 years) picker; hidden in Day View.
        const pick = mk("div", "pjdp-pick", body);
        pick.setAttribute("role", "group");
        pick.hidden = true;
        const pickCells: HTMLButtonElement[] = [];
        for (let i = 0; i < PICK_CELLS; i += 1) {
            const c = btn("pjdp-pick-cell", pick);
            c.dataset.index = String(i);
            pickCells.push(c);
        }

        const footer = mk("div", "pjdp-footer", body);
        const today = btn("pjdp-btn pjdp-btn--ghost", footer);
        const clear = btn("pjdp-btn pjdp-btn--ghost", footer);
        mk("div", "pjdp-spacer", footer);
        const cancel = btn("pjdp-btn pjdp-btn--ghost", footer);
        const apply = btn("pjdp-btn pjdp-btn--primary", footer);

        const message = mk("div", "pjdp-message", body);
        message.setAttribute("role", "status");
        message.setAttribute("aria-live", "polite");

        return {
            header, display, fromBox, fromLabel, fromValue, toBox, toLabel, toValue, pending,
            prevYear, prevMonth, monthLabel, monthPart, yearPart, yearRange, pick, pickCells,
            nextMonth, nextYear, weekdays, grid, cells,
            today, clear, cancel, apply, message, empty, body, summary, summaryText
        };
    }

    private bindEvents(): void {
        const guard = (fn: () => void) => () => {
            try {
                fn();
            } catch {
                this.setMessage(this.strings.msgInvalidDate, "error");
                this.safeRender();
            }
        };
        this.el.prevYear.addEventListener("click", guard(() => this.shiftMonths(-12)));
        this.el.prevMonth.addEventListener("click", guard(() => this.onNavStep(-1)));
        this.el.nextMonth.addEventListener("click", guard(() => this.onNavStep(1)));
        this.el.monthPart.addEventListener("click", guard(() => this.drillToMonths()));
        this.el.yearPart.addEventListener("click", guard(() => this.drillToYears()));
        this.el.pick.addEventListener("click", (ev) => guard(() => {
            const b = (ev.target as HTMLElement | null)?.closest?.("button.pjdp-pick-cell") as HTMLButtonElement | null;
            if (b && !b.disabled) {
                this.pickFocus = Number(b.dataset.index);
                this.onPickSelected(this.pickFocus);
            }
        })());
        this.el.pick.addEventListener("keydown", (ev) => guard(() => this.onPickKey(ev))());
        this.el.nextYear.addEventListener("click", guard(() => this.shiftMonths(12)));
        this.el.today.addEventListener("click", guard(() => this.doToday()));
        this.el.clear.addEventListener("click", guard(() => this.doClear()));
        this.el.cancel.addEventListener("click", guard(() => this.doCancel()));
        this.el.apply.addEventListener("click", guard(() => this.doApply()));
        this.el.summary.addEventListener("click", guard(() => this.open()));

        this.el.grid.addEventListener("click", (ev) => guard(() => {
            const day = this.dayFromEvent(ev);
            if (day !== null) {
                this.onDayActivated(day);
                this.focusCell(day);
            }
        })());

        this.el.grid.addEventListener("mouseover", (ev) => {
            const n = normalizeRange(this.temp);
            if (n.start === null || n.end !== null) {
                return;
            }
            const day = this.dayFromEvent(ev);
            if (day !== null && day !== this.hoverDay) {
                this.hoverDay = day;
                this.safeRenderCells();
            }
        });
        this.el.grid.addEventListener("mouseleave", () => {
            if (this.hoverDay !== null) {
                this.hoverDay = null;
                this.safeRenderCells();
            }
        });

        this.el.grid.addEventListener("keydown", (ev) => guard(() => this.onGridKey(ev))());

        this.root.addEventListener("keydown", (ev) => {
            if (ev.key === "Escape" && this.isOpen) {
                ev.preventDefault();
                ev.stopPropagation();
                // Month/Year View: go back one level. Day View: existing Cancel behaviour.
                guard(() => (this.calendarView === "day" ? this.doCancel() : this.drillBack()))();
            }
        });
    }

    private dayFromEvent(ev: Event): number | null {
        const t = ev.target as HTMLElement | null;
        const b = t?.closest?.("button.pjdp-cell") as HTMLButtonElement | null;
        if (!b || b.disabled || !b.dataset.day) {
            return null;
        }
        const d = Number(b.dataset.day);
        return Number.isInteger(d) ? d : null;
    }

    private onGridKey(ev: KeyboardEvent): void {
        const current = this.dayFromEvent(ev);
        if (current === null) {
            return;
        }
        const rtl = this.strings.dir === "rtl";
        let next: number | null = null;
        switch (ev.key) {
            case "ArrowLeft": next = current + (rtl ? 1 : -1); break;
            case "ArrowRight": next = current + (rtl ? -1 : 1); break;
            case "ArrowUp": next = current - 7; break;
            case "ArrowDown": next = current + 7; break;
            case "PageUp": next = this.shiftDayByMonths(current, ev.shiftKey ? -12 : -1); break;
            case "PageDown": next = this.shiftDayByMonths(current, ev.shiftKey ? 12 : 1); break;
            default: return;
        }
        if (next === null) {
            return;
        }
        ev.preventDefault();
        this.focusDay = next;
        this.navigateToDay(next);
        this.render();
        this.focusCell(next);
    }

    private shiftDayByMonths(day: number, delta: number): number | null {
        const j = this.model.toJalali(day);
        if (!j) {
            return null;
        }
        const m = addMonths(j.year, j.month, delta);
        const len = this.model.monthLength(m.year, m.month);
        return this.model.toDay(m.year, m.month, Math.min(j.day, len));
    }

    private focusCell(day: number): void {
        const b = this.el.cells.find((c) => c.dataset.day === String(day) && !c.disabled);
        b?.focus();
    }

    private safeRender(): void {
        try { this.render(); } catch { /* keep the report alive */ }
    }

    private safeRenderCells(): void {
        try { this.renderCells(); } catch { /* keep the report alive */ }
    }
}

/** "#RRGGBB" (or "#RGB") + alpha -> rgba(). Other color strings are returned unchanged. */
function toRgba(color: string, alpha: number): string {
    const a = Math.max(0, Math.min(1, alpha));
    let hex = color.trim();
    if (/^#[0-9a-f]{3}$/i.test(hex)) {
        hex = `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
    }
    const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex);
    if (!m) {
        return color;
    }
    return `rgba(${parseInt(m[1], 16)}, ${parseInt(m[2], 16)}, ${parseInt(m[3], 16)}, ${a})`;
}

/** Small calendar glyph built with DOM APIs (no innerHTML, no external assets). */
function calendarIcon(): SVGSVGElement {
    const NS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 16 16");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("class", "pjdp-summary-icon");
    const parts: [string, Record<string, string>][] = [
        ["rect", { x: "1.5", y: "2.5", width: "13", height: "12", rx: "2", fill: "none", stroke: "currentColor", "stroke-width": "1.3" }],
        ["path", { d: "M1.5 6.2h13", stroke: "currentColor", "stroke-width": "1.3" }],
        ["path", { d: "M5 1v3M11 1v3", stroke: "currentColor", "stroke-width": "1.3", "stroke-linecap": "round" }],
        ["rect", { x: "4", y: "8.5", width: "2.4", height: "2.2", rx: ".4", fill: "currentColor" }],
        ["rect", { x: "9.6", y: "8.5", width: "2.4", height: "2.2", rx: ".4", fill: "currentColor", opacity: ".45" }]
    ];
    for (const [tag, attrs] of parts) {
        const el = document.createElementNS(NS, tag);
        for (const [k, v] of Object.entries(attrs)) {
            el.setAttribute(k, v);
        }
        svg.appendChild(el);
    }
    return svg;
}
