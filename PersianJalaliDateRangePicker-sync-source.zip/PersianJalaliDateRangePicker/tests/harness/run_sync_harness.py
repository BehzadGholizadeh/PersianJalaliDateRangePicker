"""
Multi-instance sync harness: two or more copies of the PACKAGED visual in one page,
coordinated ONLY through a mock Power BI filter store (sync-mock.js), as Sync slicers do.
NOT Power BI.  Run:  python3 tests/harness/run_sync_harness.py
"""
import json, os, sys, zipfile, datetime, re
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
with zipfile.ZipFile(os.path.join(ROOT, "dist", "PersianJalaliDateRangePicker.pbiviz")) as z:
    res = json.loads(z.read([n for n in z.namelist() if n.startswith("resources/") and n.endswith(".json")][0]))
JS, CSS, CAPS = res["content"]["js"], res["content"]["css"], res["capabilities"]
MOCK = open(os.path.join(os.path.dirname(__file__), "sync-mock.js"), encoding="utf-8").read()
TZ = os.environ.get("HARNESS_TZ", "Asia/Tehran")
ARROW = "←"
results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond))); print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail and not cond else ""))

check("capabilities: supportsSynchronizingFilterState = true", CAPS.get("supportsSynchronizingFilterState") is True)
for api in ["localStorage", "sessionStorage", "BroadcastChannel", "postMessage", "SharedWorker", "indexedDB", "document.cookie"]:
    check(f"bundle does not use {api}", api not in JS)

HTML = f"""<!doctype html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body>
<script>window.powerbi={{}};</script><script>{JS}</script><script>{MOCK}</script></body></html>"""

with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(timezone_id=TZ, viewport={"width": 1000, "height": 700}); page = ctx.new_page()
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.clock.install(time=datetime.datetime(2026, 10, 5, 6, 30, tzinfo=datetime.timezone.utc))
    page.set_content(HTML)
    w = lambda ms=40: page.wait_for_timeout(ms)
    def ev(js): return page.evaluate(js)
    summary = lambda v: ev(f"document.querySelector('#{v} .pjdp-summary-text').textContent")
    fields = lambda v: ev(f"[...document.querySelectorAll('#{v} .pjdp-field-value')].map(e=>e.textContent)")
    is_open = lambda v: ev(f"!document.querySelector('#{v} .pjdp-body').hidden")
    calls = lambda v: ev(f"S.members['{v}'].calls.length")
    updates = lambda v: ev(f"S.members['{v}'].updates")
    def open_(v): page.click(f"#{v} button.pjdp-summary"); w(20)
    def day(v, label): page.click(f'#{v} button.pjdp-cell[aria-label="انتخاب {label}"]'); w(10)
    def btn(v, name): page.click(f'#{v} button.pjdp-btn:text-is("{name}")'); w()
    def prev(v): page.click(f'#{v} button[aria-label="ماه قبل"]'); w(10)
    R = lambda a, b: f"{a}  {ARROW}  {b}"

    ev("S.add('v1'); S.add('v2')"); w()
    check("S0 both instances start neutral", summary("v1") == summary("v2") == "انتخاب بازه تاریخ")

    # S1: apply in v1 -> v2 follows
    open_("v1"); day("v1", "۱۴۰۵/۰۷/۰۱"); day("v1", "۱۴۰۵/۰۷/۱۵")
    check("S1 temporary selection in v1 is NOT shared (no filter yet)", calls("v1") == 0 and summary("v2") == "انتخاب بازه تاریخ")
    btn("v1", "اعمال")
    check("S1 v1 applied & collapsed", summary("v1") == R("۱۴۰۵/۰۷/۰۱", "۱۴۰۵/۰۷/۱۵"), summary("v1"))
    check("S1 v2 shows the same range via filter state", summary("v2") == R("۱۴۰۵/۰۷/۰۱", "۱۴۰۵/۰۷/۱۵"), summary("v2"))
    check("S1 v2 did not call applyJsonFilter (no echo loop)", calls("v2") == 0)
    open_("v2")
    check("S1 opening v2 preselects the synced range", fields("v2") == ["۱۴۰۵/۰۷/۰۱", "۱۴۰۵/۰۷/۱۵"], str(fields("v2")))

    # S2: change in v2 -> v1 follows (within the old 4 s window: regression of the fixed bug)
    day("v2", "۱۴۰۵/۰۷/۲۰"); day("v2", "۱۴۰۵/۰۷/۱۰"); btn("v2", "اعمال")
    check("S2 v2 applied normalized range", summary("v2") == R("۱۴۰۵/۰۷/۱۰", "۱۴۰۵/۰۷/۲۰"), summary("v2"))
    check("S2 v1 synced to v2's range immediately (< 4 s after its own Apply)", summary("v1") == R("۱۴۰۵/۰۷/۱۰", "۱۴۰۵/۰۷/۲۰"), summary("v1"))
    check("S2 exactly one host call per user Apply", calls("v1") == 1 and calls("v2") == 1)

    # S3: temporary state is never overwritten by an external change
    open_("v2"); day("v2", "۱۴۰۵/۰۷/۰۲"); day("v2", "۱۴۰۵/۰۷/۰۴")       # v2 dirty, not applied
    open_("v1"); day("v1", "۱۴۰۵/۰۷/۲۵"); day("v1", "۱۴۰۵/۰۷/۲۸"); btn("v1", "اعمال")
    check("S3 v2's un-applied temporary selection kept", is_open("v2") and fields("v2") == ["۱۴۰۵/۰۷/۰۲", "۱۴۰۵/۰۷/۰۴"], str(fields("v2")))
    check("S3 v2's applied markers moved to the new external range",
          ev("[...document.querySelectorAll('#v2 .pjdp-cell--applied')].map(b=>b.textContent).join(',')") == "۲۵,۲۶,۲۷,۲۸")
    btn("v2", "انصراف")
    check("S3 cancel in v2 returns to the CURRENT filter state (from v1)", summary("v2") == R("۱۴۰۵/۰۷/۲۵", "۱۴۰۵/۰۷/۲۸"), summary("v2"))
    check("S3 cancel sent nothing", calls("v2") == 1)

    # S4: open but untouched v2 follows external changes live
    open_("v2"); open_("v1") if not is_open("v1") else None
    day("v1", "۱۴۰۵/۰۷/۰۵"); btn("v1", "اعمال")
    check("S4 untouched open v2 follows live", is_open("v2") and fields("v2") == ["۱۴۰۵/۰۷/۰۵", "۱۴۰۵/۰۷/۰۵"], str(fields("v2")))
    btn("v2", "انصراف")

    # S5: Clear in one -> other returns to neutral
    open_("v2"); btn("v2", "پاک کردن")
    check("S5 clear in v2 -> v2 neutral", summary("v2") == "انتخاب بازه تاریخ")
    check("S5 clear in v2 -> v1 neutral (no filter on MDate)", summary("v1") == "انتخاب بازه تاریخ", summary("v1"))
    check("S5 store empty", ev("S.store.filters.length") == 0)

    # S6: external clear while dirty keeps temp; cancel then shows neutral
    open_("v1"); day("v1", "۱۴۰۵/۰۷/۰۱"); btn("v1", "اعمال")
    open_("v1"); day("v1", "۱۴۰۵/۰۷/۰۹")
    open_("v2"); btn("v2", "پاک کردن")
    check("S6 v1 temp kept after external clear", is_open("v1") and fields("v1")[0] == "۱۴۰۵/۰۷/۰۹", str(fields("v1")))
    btn("v1", "انصراف")
    check("S6 v1 cancel -> neutral (filter state has no range)", summary("v1") == "انتخاب بازه تاریخ", summary("v1"))

    # S7: no loops / no runaway updates
    c1, c2, u1, u2 = calls("v1"), calls("v2"), updates("v1"), updates("v2")
    w(600)
    check("S7 idle: no further host calls or updates (no loop)", (calls("v1"), calls("v2"), updates("v1"), updates("v2")) == (c1, c2, u1, u2))
    ev("S.broadcast(); S.broadcast(); S.broadcast()"); w(50)
    check("S7 repeated identical filter pushes never trigger applyJsonFilter", (calls("v1"), calls("v2")) == (c1, c2))

    # S8: host lag (old state echoed first) does not make the applier flicker back
    ev("S.cfg.lagFirstEcho = true; S.cfg.echoDelay = 120")
    open_("v1"); day("v1", "۱۴۰۵/۰۸/۰۱") if False else None
    page.click('#v1 button[aria-label="ماه بعد"]'); w(10); day("v1", "۱۴۰۵/۰۸/۰۱"); day("v1", "۱۴۰۵/۰۸/۰۳"); btn("v1", "اعمال")
    check("S8 lagging old echo ignored by applier", summary("v1") == R("۱۴۰۵/۰۸/۰۱", "۱۴۰۵/۰۸/۰۳"), summary("v1"))
    w(250)
    check("S8 after lag both converge on new range", summary("v1") == summary("v2") == R("۱۴۰۵/۰۸/۰۱", "۱۴۰۵/۰۸/۰۳"), f"{summary('v1')} | {summary('v2')}")
    ev("S.cfg.lagFirstEcho = false; S.cfg.echoDelay = 0")

    # S9: "other page" — instance created later (page navigation) restores from filter state
    ev("S.remove('v2'); S.add('v3')"); w()
    check("S9 newly loaded instance (other page) shows current range", summary("v3") == R("۱۴۰۵/۰۸/۰۱", "۱۴۰۵/۰۸/۰۳") and calls("v3") == 0, summary("v3"))

    # S10: three instances, change from the newest
    ev("S.add('v4')"); w(); open_("v4"); btn("v4", "پاک کردن")
    check("S10 three-way sync: clear in v4 neutralises v1 and v3", summary("v1") == summary("v3") == "انتخاب بازه تاریخ")

    # S11: instance NOT in a sync group keeps its own state (Power BI decides grouping)
    ev("S.add('solo', false)"); w(); open_("v1"); day("v1", "۱۴۰۵/۰۷/۰۳"); btn("v1", "اعمال")
    check("S11 un-synced instance is unaffected", summary("solo") == "انتخاب بازه تاریخ" and summary("v3") == "۱۴۰۵/۰۷/۰۳", f"{summary('solo')} | {summary('v3')}")

    # S12: uninterpretable filter state -> neutral, no crash, no write-back
    ev("""S.store.filters=[{"$schema":"http://powerbi.com/product/schema#basic","target":{"table":"Dates_Dim","column":"MDate"},"filterType":1,"operator":"In","values":[1]}]; S.broadcast();"""); w()
    check("S12 unknown filter shape -> neutral, nothing written back", summary("v1") == summary("v3") == "انتخاب بازه تاریخ" and calls("v3") == 0)

    # S13: host that does NOT echo a filter back to the visual that applied it (unverified real-host behaviour).
    # v1 applies, then v3 changes the range within 4 s: v1 must still follow Power BI's filter state.
    ev("S.cfg.noSelfEcho = true")
    open_("v1"); day("v1", "۱۴۰۵/۰۷/۰۱"); day("v1", "۱۴۰۵/۰۷/۰۲"); btn("v1", "اعمال")
    open_("v3"); day("v3", "۱۴۰۵/۰۷/۰۴"); day("v3", "۱۴۰۵/۰۷/۰۶"); btn("v3", "اعمال")
    check("S13 no self-echo: v1 follows v3's change made within 4 s", summary("v1") == R("۱۴۰۵/۰۷/۰۴", "۱۴۰۵/۰۷/۰۶"), summary("v1"))
    open_("v1"); btn("v1", "پاک کردن"); open_("v3"); day("v3", "۱۴۰۵/۰۷/۱۰"); btn("v3", "اعمال")
    check("S13 no self-echo: v1 follows a change made right after its own Clear", summary("v1") == "۱۴۰۵/۰۷/۱۰", summary("v1"))
    ev("S.cfg.noSelfEcho = false")

    page.screenshot(path=os.path.join(ROOT, "tests", "harness", "screenshots", "sync_instances.png"))
    check("no page/console errors", not errors, str(errors[:3]))
    check("no render failures", ev("Object.values(S.members).every(m=>!m.failed)"))
    b.close()

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)}/{len(results)} sync checks passed (TZ={TZ})")
sys.exit(1 if failed else 0)
