// Mock of a Power BI *sync slicers* group for harness tests. NOT shipped in the visual.
// Several visual instances share ONE filter store (Power BI's filter state). Instances never
// talk to each other: a filter change goes visual -> host store -> update({jsonFilters}) of every member.
window.S = (() => {
  const fmt = new Intl.DateTimeFormat("en-US-u-ca-persian-nu-latn", { year: "numeric", month: "2-digit", day: "2-digit" });
  const jid = d => { const p = Object.fromEntries(fmt.formatToParts(d).map(x => [x.type, x.value])); return `${p.year.replace(/\D/g, "")}/${p.month}/${p.day}`; };
  const dates = [], ids = [];
  for (let i = 0; i < 1170; i++) { const d = new Date(2024, 2, 20 + i); dates.push(d); ids.push(jid(d)); }
  const dv = () => ({ metadata: { columns: [], objects: {} }, categorical: { categories: [
    { source: { queryName: "Dates_Dim.MDate", displayName: "MDate", roles: { Date: true } }, values: dates },
    { source: { queryName: "Dates_Dim.Date_ID", displayName: "Date_ID", roles: { JalaliDate: true } }, values: ids } ] } });
  const store = { filters: [] };                  // Power BI filter state for the sync group
  const members = {};                              // id -> {visual, el, calls, updates, synced}
  const cfg = { echoDelay: 0, lagFirstEcho: false, noSelfEcho: false };
  const dataView = dv();
  function pushTo(m, filters) {
    m.updates++;
    m.visual.update({ viewport: { width: 400, height: 300 }, dataViews: [dataView], type: 2, operationKind: 0,
      jsonFilters: filters.map(f => structuredClone(f)) });
  }
  function broadcast() { for (const id in members) if (members[id].synced) pushTo(members[id], store.filters); }
  function makeHost(id) {
    return {
      applyJsonFilter(f, obj, prop, action) {
        const m = members[id]; m.calls.push({ f: f && structuredClone(f), action });
        const next = action === 1 ? [] : [structuredClone(f)];
        if (!m.synced) { m.own = next; setTimeout(() => pushTo(m, m.own), cfg.echoDelay); return; }
        if (cfg.lagFirstEcho) {               // host first re-sends the OLD state, then the new one
          const old = store.filters; setTimeout(() => pushTo(m, old), 0);
        }
        // noSelfEcho: host updates the filter state but does not send an update back to the applier.
        setTimeout(() => { store.filters = next; for (const k in members) if (members[k].synced && !(cfg.noSelfEcho && k === id)) pushTo(members[k], store.filters); }, cfg.echoDelay);
      },
      fetchMoreData: () => false,
      eventService: { renderingStarted() {}, renderingFinished() {}, renderingFailed(o, r) { members[id].failed = r; } },
      hostCapabilities: { allowInteractions: true },
      colorPalette: { isHighContrast: false },
      switchFocusModeState() {}
    };
  }
  function add(id, synced = true) {
    let el = document.getElementById(id);
    if (!el) { el = document.createElement("div"); el.id = id; el.style.cssText = "position:relative;width:400px;height:300px;display:inline-block;margin:4px;vertical-align:top"; document.body.appendChild(el); }
    el.replaceChildren();
    const visual = window.powerbi.visuals.plugins.PersianJalaliDateRangePickerA7C31F0E9B2D4.create({ element: el, host: makeHost(id) });
    members[id] = { visual, el, calls: [], updates: 0, synced, own: [] };
    pushTo(members[id], synced ? store.filters : []);   // page load: host restores current filter state
  }
  function remove(id) { members[id].visual.destroy(); delete members[id]; document.getElementById(id).remove(); }
  return { store, members, cfg, add, remove, broadcast };
})();
